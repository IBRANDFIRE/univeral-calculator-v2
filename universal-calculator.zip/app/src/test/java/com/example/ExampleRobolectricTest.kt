package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.HighPrecisionEvaluator
import com.example.engine.ScientificCalculators
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import kotlin.math.abs

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Universal Calculator", appName)
  }

  @Test
  fun `launch MainActivity`() {
    val controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
    val activity = controller.get()
    assertNotNull(activity)
  }

  @Test
  fun `test standard arithmetic and precedence`() {
    val res = HighPrecisionEvaluator.evaluate("2 + 3 * 4")
    assertTrue(res.success)
    assertEquals(14.0, res.value, 1e-9)
    assertEquals("14", res.formatted)
  }

  @Test
  fun `test implicit multiplication`() {
    val res1 = HighPrecisionEvaluator.evaluate("2(3 + 4)")
    assertTrue(res1.success)
    assertEquals(14.0, res1.value, 1e-9)

    val res2 = HighPrecisionEvaluator.evaluate("(2 + 1)(3 + 1)")
    assertTrue(res2.success)
    assertEquals(12.0, res2.value, 1e-9)

    val res3 = HighPrecisionEvaluator.evaluate("2sin(30)")
    assertTrue(res3.success)
    assertEquals(1.0, res3.value, 1e-9)
  }

  @Test
  fun `test percentage calculation`() {
    val res1 = HighPrecisionEvaluator.evaluate("50%")
    assertTrue(res1.success)
    assertEquals(0.5, res1.value, 1e-9)

    val res2 = HighPrecisionEvaluator.evaluate("100 * 20%")
    assertTrue(res2.success)
    assertEquals(20.0, res2.value, 1e-9)
  }

  @Test
  fun `test scientific functions and degrees`() {
    val sin30 = HighPrecisionEvaluator.evaluate("sin(30)")
    assertTrue(sin30.success)
    assertEquals(0.5, sin30.value, 1e-9)

    val cos90 = HighPrecisionEvaluator.evaluate("cos(90)")
    assertTrue(cos90.success)
    assertEquals(0.0, cos90.value, 1e-9)

    val fact5 = HighPrecisionEvaluator.evaluate("5!")
    assertTrue(fact5.success)
    assertEquals(120.0, fact5.value, 1e-9)

    val expZero = HighPrecisionEvaluator.evaluate("exp(0)")
    assertTrue(expZero.success)
    assertEquals(1.0, expZero.value, 1e-9)
  }

  @Test
  fun `test division by zero handling`() {
    val res = HighPrecisionEvaluator.evaluate("10 / 0")
    assertFalse(res.success)
    assertEquals("Cannot divide by zero", res.error)
  }

  @Test
  fun `test scientificCalculators evaluateFunction and roots`() {
    val res1 = ScientificCalculators.evaluateFunction("2x + 1", 3.0)
    assertEquals(7.0, res1, 1e-9)

    val resExp = ScientificCalculators.evaluateFunction("exp(x)", 0.0)
    assertEquals(1.0, resExp, 1e-9)

    val roots = ScientificCalculators.findRoots("x^2 - 4", -3.0, 3.0)
    assertTrue(roots.isNotEmpty())
    assertTrue(roots.any { abs(it - (-2.0)) < 0.2 })
    assertTrue(roots.any { abs(it - 2.0) < 0.2 })
  }

  @Test
  fun `test settings manager keypad order and sound`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val settingsManager = com.example.data.SettingsManager(context)

    // Default should be TOP_DOWN (numbers 1-2-3 up to down)
    assertEquals(com.example.data.KeypadOrder.TOP_DOWN, settingsManager.settings.value.keypadOrder)
    assertTrue(settingsManager.settings.value.soundEnabled)

    // Switch to classic bottom-up
    settingsManager.setKeypadOrder(com.example.data.KeypadOrder.BOTTOM_UP)
    assertEquals(com.example.data.KeypadOrder.BOTTOM_UP, settingsManager.settings.value.keypadOrder)

    // Switch sound toggle
    settingsManager.setSoundEnabled(false)
    assertFalse(settingsManager.settings.value.soundEnabled)
    settingsManager.setSoundEnabled(true)
    assertTrue(settingsManager.settings.value.soundEnabled)
  }

  @Test
  fun `test multiple accent palettes and colors`() {
    val palettes = com.example.data.AccentPalette.values()
    assertTrue(palettes.size >= 12)
    palettes.forEach { palette ->
      val darkColor = com.example.ui.theme.getPrimaryColor(palette, isDark = true)
      val lightColor = com.example.ui.theme.getPrimaryColor(palette, isDark = false)
      assertNotNull(darkColor)
      assertNotNull(lightColor)
    }
  }

  @Test
  fun `test sound feedback manager`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val soundManager = com.example.ui.components.SoundFeedbackManager(context, soundEnabled = true)
    soundManager.playClick()
    soundManager.playHeavyClick()
    soundManager.playBackspace()
    soundManager.soundEnabled = false
    soundManager.playClick()
    soundManager.release()
  }

  @Test
  fun `test studentMathSolver find x equation solver`() {
    val res1 = com.example.engine.StudentMathSolver.solveEquationForX("2x + 5 = 15")
    assertTrue(res1.success)
    assertTrue(res1.roots.any { abs(it - 5.0) < 1e-3 })

    val res2 = com.example.engine.StudentMathSolver.solveEquationForX("x^2 - 9 = 0")
    assertTrue(res2.success)
    assertTrue(res2.roots.any { abs(it - 3.0) < 1e-3 })
    assertTrue(res2.roots.any { abs(it - (-3.0)) < 1e-3 })
  }

  @Test
  fun `test studentMathSolver cubic equation`() {
    val cubic = com.example.engine.StudentMathSolver.solveCubic(1.0, -6.0, 11.0, -6.0)
    assertEquals(3, cubic.realRootsCount)
    assertTrue(cubic.roots.contains("1"))
    assertTrue(cubic.roots.contains("2"))
    assertTrue(cubic.roots.contains("3"))
  }

  @Test
  fun `test studentMathSolver AP and GP`() {
    val ap = com.example.engine.StudentMathSolver.calculateAP(2.0, 3.0, 5)
    assertEquals(14.0, ap.nthTerm, 1e-9) // 2 + 4*3 = 14
    assertEquals(40.0, ap.sumN, 1e-9)   // 5/2 * (4 + 12) = 40

    val gp = com.example.engine.StudentMathSolver.calculateGP(3.0, 2.0, 4)
    assertEquals(24.0, gp.nthTerm, 1e-9) // 3 * 2^3 = 24
    assertEquals(45.0, gp.sumN, 1e-9)   // 3*(16-1)/1 = 45
  }

  @Test
  fun `test studentMathSolver series summation`() {
    val sigma = com.example.engine.StudentMathSolver.calculateSeriesSum("k", 1, 10)
    assertEquals(55.0, sigma.sumValue, 1e-9) // 10*11/2 = 55
  }

  @Test
  fun `test physics science solver kinematics and projectile`() {
    val kin = com.example.engine.PhysicsScienceSolver.solveKinematics(0.0, 20.0, 10.0, null, null)
    assertEquals("2.0 s", kin.valuesMap["Time (t)"])

    val proj = com.example.engine.PhysicsScienceSolver.solveProjectile(30.0, 45.0)
    assertNotNull(proj.valuesMap["Horizontal Range (R)"])
  }

  @Test
  fun `test physics science solver circuits and optics`() {
    val circuit = com.example.engine.PhysicsScienceSolver.solveCircuits(220.0, 5.0, null, emptyList(), true)
    assertEquals("44.0 Ω", circuit.valuesMap["Equivalent Resistance (R)"])

    val optics = com.example.engine.PhysicsScienceSolver.solveOptics(-20.0, 10.0, isMirror = false)
    assertEquals("20.0 cm", optics.valuesMap["Image Distance (v)"])
  }
}
