package com.example

import com.example.engine.*
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testHighPrecisionEvaluator() {
        val r1 = HighPrecisionEvaluator.evaluate("2 + 3 * 4")
        assertTrue(r1.success)
        assertEquals(14.0, r1.value!!, 1e-6)

        val r2 = HighPrecisionEvaluator.evaluate("(10 - 2) / 4 + 5^2")
        assertTrue(r2.success)
        assertEquals(27.0, r2.value!!, 1e-6)

        val r3 = HighPrecisionEvaluator.evaluate("sqrt(16) + 3!")
        assertTrue(r3.success)
        assertEquals(10.0, r3.value!!, 1e-6)

        val r4 = HighPrecisionEvaluator.evaluate("sin(90)", HighPrecisionEvaluator.AngleUnit.DEGREES)
        assertTrue(r4.success)
        assertEquals(1.0, r4.value!!, 1e-6)
    }

    @Test
    fun testFinancialCalculators() {
        // Loan EMI: 100,000 at 10% for 1 year (12 months)
        val emi = FinancialCalculators.calculateLoanEmi(100000.0, 10.0, 1.0)
        assertTrue(emi.monthlyEmi > 8000.0 && emi.monthlyEmi < 9000.0)
        assertTrue(emi.totalPayment > 100000.0)

        // SIP: 1,000 per month at 12% for 5 years
        val sip = FinancialCalculators.calculateSip(1000.0, 12.0, 5)
        assertTrue(sip.totalInvested == 60000.0)
        assertTrue(sip.totalMaturity > 80000.0)

        // Tip calculation: $100 bill, 20% tip, 2 people
        val tip = FinancialCalculators.calculateTip(100.0, 20.0, 2)
        assertEquals(20.0, tip.tipAmount, 1e-2)
        assertEquals(120.0, tip.totalAmount, 1e-2)
        assertEquals(60.0, tip.perPersonTotal, 1e-2)
    }

    @Test
    fun testUnitConverters() {
        // 1 km = 1000 meters
        val meters = UnitConverters.convert(1.0, UnitConverters.Category.LENGTH, "km", "m")
        assertEquals(1000.0, meters, 1e-6)

        // 1 meter = 100 cm
        val cm = UnitConverters.convert(1.0, UnitConverters.Category.LENGTH, "m", "cm")
        assertEquals(100.0, cm, 1e-6)

        // Base conversions: 255 in hex is FF, in bin is 11111111
        val baseConv = UnitConverters.convertBase("255", 10)
        assertNotNull(baseConv)
        assertEquals("FF", baseConv!!.hexadecimal)
        assertEquals("377", baseConv.octal)
        assertTrue(baseConv.binary.replace(" ", "").endsWith("11111111"))
    }

    @Test
    fun testHealthCalculators() {
        // BMI: 70kg, 175cm -> BMI ≈ 22.86 (Normal)
        val bmi = HealthCalculators.calculateBmi(70.0, 175.0)
        assertEquals(22.86, bmi.bmi, 0.1)
        assertEquals("Normal weight", bmi.category)

        // BMR: 70kg, 175cm, 25 yo Male -> 10*70 + 6.25*175 - 5*25 + 5 = 700 + 1093.75 - 125 + 5 = 1673.75
        val bmrMale = HealthCalculators.calculateBmr(70.0, 175.0, 25, HealthCalculators.Gender.MALE)
        assertEquals(1673.75, bmrMale, 1e-2)
    }

    @Test
    fun testScientificCalculators() {
        // Quadratic: x^2 - 5x + 6 = 0 -> roots are 2 and 3
        val quad = ScientificCalculators.solveQuadratic(1.0, -5.0, 6.0)
        assertTrue(quad is ScientificCalculators.QuadraticResult.RealRoots)
        val realRoots = quad as ScientificCalculators.QuadraticResult.RealRoots
        assertEquals(3.0, realRoots.x1, 1e-6)
        assertEquals(2.0, realRoots.x2, 1e-6)

        // Statistics
        val stats = ScientificCalculators.calculateStatistics(listOf(1.0, 2.0, 3.0, 4.0, 5.0))
        assertNotNull(stats)
        assertEquals(3.0, stats!!.mean, 1e-6)
        assertEquals(3.0, stats.median, 1e-6)
        assertEquals(5, stats.count)

        // 2x2 Matrix det: [[2, 1], [4, 3]] -> 2*3 - 1*4 = 2
        val mat = arrayOf(doubleArrayOf(2.0, 1.0), doubleArrayOf(4.0, 3.0))
        val res = ScientificCalculators.solveMatrix2x2(mat)
        assertEquals(2.0, res.determinant, 1e-6)
        assertNotNull(res.inverse)
    }
}
