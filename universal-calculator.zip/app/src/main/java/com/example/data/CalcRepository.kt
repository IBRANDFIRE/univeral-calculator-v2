package com.example.data

import kotlinx.coroutines.flow.Flow

class CalcRepository(private val dao: CalcHistoryDao) {
    val allHistory: Flow<List<CalcHistoryEntity>> = dao.getAllHistory()
    val recentHistory: Flow<List<CalcHistoryEntity>> = dao.getRecentHistory(15)

    fun search(query: String): Flow<List<CalcHistoryEntity>> = dao.searchHistory(query)
    fun getByCategory(category: String): Flow<List<CalcHistoryEntity>> = dao.getHistoryByCategory(category)

    suspend fun saveCalculation(
        category: String,
        calculatorName: String,
        expression: String,
        result: String,
        details: String = "",
        label: String = ""
    ): Long {
        val entry = CalcHistoryEntity(
            category = category,
            calculatorName = calculatorName,
            expression = expression,
            result = result,
            details = details,
            label = label
        )
        return dao.insert(entry)
    }

    suspend fun delete(id: Long) = dao.deleteById(id)
    suspend fun clear() = dao.clearAll()
    suspend fun togglePin(id: Long) = dao.togglePin(id)
    suspend fun updateLabel(id: Long, label: String) = dao.updateLabel(id, label)
}
