package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppThemeMode {
    SYSTEM, DARK, LIGHT
}

enum class KeypadOrder(val displayName: String, val description: String) {
    TOP_DOWN("1-2-3 (Top-Down)", "Numbers 1, 2, 3 at the top row"),
    BOTTOM_UP("7-8-9 (Classic)", "Numbers 7, 8, 9 at the top row")
}

enum class AccentPalette(val displayName: String, val primaryHex: Long) {
    SAPPHIRE("Sapphire Blue", 0xFF2563EB),
    EMERALD("Emerald Green", 0xFF059669),
    AMBER("Electric Amber", 0xFFD97706),
    AMETHYST("Amethyst Purple", 0xFF7C3AED),
    CORAL("Coral Crimson", 0xFFE11D48),
    RUBY("Ruby Rose", 0xFFDB2777),
    SUNSET("Sunset Orange", 0xFFEA580C),
    TEAL("Nordic Teal", 0xFF0D9488),
    CYAN("Electric Cyan", 0xFF0284C7),
    INDIGO("Midnight Indigo", 0xFF4F46E5),
    VIOLET("Neon Violet", 0xFF9333EA),
    GOLD("Champagne Gold", 0xFFCA8A04),
    MINT("Fresh Mint", 0xFF16A34A),
    SLATE("Slate Minimal", 0xFF475569)
}

data class UserSettingsState(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val accentPalette: AccentPalette = AccentPalette.SAPPHIRE,
    val keypadOrder: KeypadOrder = KeypadOrder.TOP_DOWN,
    val hapticsEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val decimalPrecision: Int = 4,
    val memoryValue: Double = 0.0,
    val pinnedCalculators: Set<String> = setOf("standard", "scientific", "emi", "currency", "bmi", "units")
) {
    val accent: AccentPalette get() = accentPalette
    val hapticFeedbackEnabled: Boolean get() = hapticsEnabled
}

class SettingsManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("universal_calc_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<UserSettingsState> = _settings.asStateFlow()

    private fun loadSettings(): UserSettingsState {
        val themeStr = prefs.getString("theme_mode", AppThemeMode.DARK.name) ?: AppThemeMode.DARK.name
        val themeMode = try { AppThemeMode.valueOf(themeStr) } catch (e: Exception) { AppThemeMode.DARK }

        val accentStr = prefs.getString("accent_palette", AccentPalette.SAPPHIRE.name) ?: AccentPalette.SAPPHIRE.name
        val accent = try { AccentPalette.valueOf(accentStr) } catch (e: Exception) { AccentPalette.SAPPHIRE }

        val orderStr = prefs.getString("keypad_order", KeypadOrder.TOP_DOWN.name) ?: KeypadOrder.TOP_DOWN.name
        val order = try { KeypadOrder.valueOf(orderStr) } catch (e: Exception) { KeypadOrder.TOP_DOWN }

        val haptics = prefs.getBoolean("haptics_enabled", true)
        val sound = prefs.getBoolean("sound_enabled", true)
        val precision = prefs.getInt("decimal_precision", 4)
        val memory = prefs.getFloat("memory_value", 0.0f).toDouble()
        val pinned = prefs.getStringSet("pinned_calcs", setOf("standard", "scientific", "emi", "currency", "bmi", "units")) ?: emptySet()

        return UserSettingsState(
            themeMode = themeMode,
            accentPalette = accent,
            keypadOrder = order,
            hapticsEnabled = haptics,
            soundEnabled = sound,
            decimalPrecision = precision,
            memoryValue = memory,
            pinnedCalculators = pinned
        )
    }

    fun setKeypadOrder(order: KeypadOrder) {
        prefs.edit().putString("keypad_order", order.name).apply()
        _settings.value = _settings.value.copy(keypadOrder = order)
    }

    fun setThemeMode(mode: AppThemeMode) {
        prefs.edit().putString("theme_mode", mode.name).apply()
        _settings.value = _settings.value.copy(themeMode = mode)
    }

    fun setAccentPalette(accent: AccentPalette) {
        prefs.edit().putString("accent_palette", accent.name).apply()
        _settings.value = _settings.value.copy(accentPalette = accent)
    }

    fun setAccent(accent: AccentPalette) = setAccentPalette(accent)

    fun setHapticsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("haptics_enabled", enabled).apply()
        _settings.value = _settings.value.copy(hapticsEnabled = enabled)
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("sound_enabled", enabled).apply()
        _settings.value = _settings.value.copy(soundEnabled = enabled)
    }

    fun setDecimalPrecision(precision: Int) {
        prefs.edit().putInt("decimal_precision", precision).apply()
        _settings.value = _settings.value.copy(decimalPrecision = precision)
    }

    fun setPrecision(precision: Int) = setDecimalPrecision(precision)

    fun setMemoryValue(value: Double) {
        prefs.edit().putFloat("memory_value", value.toFloat()).apply()
        _settings.value = _settings.value.copy(memoryValue = value)
    }

    fun togglePinCalculator(calcId: String) {
        val current = _settings.value.pinnedCalculators.toMutableSet()
        if (current.contains(calcId)) {
            current.remove(calcId)
        } else {
            current.add(calcId)
        }
        prefs.edit().putStringSet("pinned_calcs", current).apply()
        _settings.value = _settings.value.copy(pinnedCalculators = current)
    }

    fun togglePinnedCalculator(calcId: String) = togglePinCalculator(calcId)
}
