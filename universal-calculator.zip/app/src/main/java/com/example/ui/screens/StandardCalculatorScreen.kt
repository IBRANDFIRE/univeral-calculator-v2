package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CalcRepository
import com.example.data.KeypadOrder
import com.example.data.SettingsManager
import com.example.engine.HighPrecisionEvaluator
import com.example.ui.components.CalculatorDisplay
import com.example.ui.components.HapticFeedbackManager
import kotlinx.coroutines.launch

@Composable
fun StandardCalculatorScreen(
    repository: CalcRepository,
    settingsManager: SettingsManager,
    haptics: HapticFeedbackManager,
    onNavigateToHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val settings by settingsManager.settings.collectAsState()

    var expression by remember { mutableStateOf("") }
    var currentResult by remember { mutableStateOf("0") }
    var angleUnit by remember { mutableStateOf(HighPrecisionEvaluator.AngleUnit.DEGREES) }
    var isScientificExpanded by remember { mutableStateOf(false) }
    var isCalculated by remember { mutableStateOf(false) }

    // Sub-mode tabs: Standard, Discount, Tally
    var selectedSubMode by remember { mutableStateOf(0) }
    val subModes = listOf("Arithmetic", "Discount", "Tally")

    fun appendInput(char: String) {
        haptics.tick()
        val standardOps = listOf("+", "-", "×", "÷")

        if (isCalculated) {
            isCalculated = false
            if (char in standardOps || char == "%" || char == "^") {
                if (currentResult != "0" && !currentResult.contains("error", ignoreCase = true) && !currentResult.contains("invalid", ignoreCase = true) && !currentResult.contains("NaN", ignoreCase = true)) {
                    expression = currentResult + char
                } else {
                    expression = char
                }
            } else {
                expression = char
            }
        } else {
            if (char in standardOps && expression.isNotEmpty() && expression.last().toString() in standardOps) {
                expression = expression.dropLast(1) + char
            } else if (expression == "0" && char !in listOf("+", "-", "×", "÷", "%", "^", ".")) {
                expression = char
            } else {
                expression += char
            }
        }

        // Live evaluate if possible
        val eval = HighPrecisionEvaluator.evaluate(expression, angleUnit)
        if (eval.success) {
            currentResult = eval.formatted
        }
    }

    fun onEquals() {
        haptics.heavyTick()
        if (expression.isBlank()) return
        val eval = HighPrecisionEvaluator.evaluate(expression, angleUnit)
        if (eval.success) {
            currentResult = eval.formatted
            isCalculated = true
            coroutineScope.launch {
                repository.saveCalculation(
                    category = "Standard",
                    calculatorName = "Arithmetic",
                    expression = expression,
                    result = currentResult
                )
            }
        } else {
            currentResult = eval.error ?: "Error"
        }
    }

    fun onClear() {
        haptics.heavyTick()
        expression = ""
        currentResult = "0"
        isCalculated = false
    }

    fun onBackspace() {
        haptics.backspaceTick()
        if (isCalculated) {
            isCalculated = false
        }
        if (expression.isNotEmpty()) {
            expression = expression.dropLast(1)
            if (expression.isNotEmpty()) {
                val eval = HighPrecisionEvaluator.evaluate(expression, angleUnit)
                if (eval.success) currentResult = eval.formatted
            } else {
                currentResult = "0"
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("standard_calculator_screen"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Mode Selector Bar
        SingleChoiceSegmentedButtonRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
        ) {
            subModes.forEachIndexed { index, title ->
                SegmentedButton(
                    selected = selectedSubMode == index,
                    onClick = {
                        haptics.tick()
                        selectedSubMode = index
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = index, count = subModes.size),
                    modifier = Modifier.testTag("calc_submode_$index")
                ) {
                    Text(title, style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        when (selectedSubMode) {
            0 -> {
                // ARITHMETIC & SCIENTIFIC EXPANDABLE
                CalculatorDisplay(
                    expression = expression,
                    result = currentResult,
                    memoryValue = settings.memoryValue,
                    angleUnitText = if (angleUnit == HighPrecisionEvaluator.AngleUnit.DEGREES) "DEG" else "RAD",
                    onExpressionClick = { /* no-op */ },
                    onResultClick = {
                        if (currentResult.toDoubleOrNull() != null) {
                            expression = currentResult
                        }
                    }
                )

                // Memory & Utility Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Memory Buttons
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilledTonalButton(
                            onClick = {
                                haptics.tick()
                                settingsManager.setMemoryValue(0.0)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.defaultMinSize(minWidth = 40.dp, minHeight = 32.dp).testTag("mem_clear")
                        ) {
                            Text("MC", style = MaterialTheme.typography.labelSmall)
                        }
                        FilledTonalButton(
                            onClick = {
                                haptics.tick()
                                appendInput(settings.memoryValue.toString())
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.defaultMinSize(minWidth = 40.dp, minHeight = 32.dp).testTag("mem_recall")
                        ) {
                            Text("MR", style = MaterialTheme.typography.labelSmall)
                        }
                        FilledTonalButton(
                            onClick = {
                                haptics.tick()
                                val cur = currentResult.toDoubleOrNull() ?: 0.0
                                settingsManager.setMemoryValue(settings.memoryValue + cur)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.defaultMinSize(minWidth = 40.dp, minHeight = 32.dp).testTag("mem_plus")
                        ) {
                            Text("M+", style = MaterialTheme.typography.labelSmall)
                        }
                        FilledTonalButton(
                            onClick = {
                                haptics.tick()
                                val cur = currentResult.toDoubleOrNull() ?: 0.0
                                settingsManager.setMemoryValue(settings.memoryValue - cur)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.defaultMinSize(minWidth = 40.dp, minHeight = 32.dp).testTag("mem_minus")
                        ) {
                            Text("M-", style = MaterialTheme.typography.labelSmall)
                        }
                    }

                    // Scientific drawer toggle & Angle unit toggle & Keypad layout toggle
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                        val isTopDown = settings.keypadOrder == KeypadOrder.TOP_DOWN
                        FilterChip(
                            selected = isTopDown,
                            onClick = {
                                haptics.tick()
                                settingsManager.setKeypadOrder(
                                    if (isTopDown) KeypadOrder.BOTTOM_UP else KeypadOrder.TOP_DOWN
                                )
                            },
                            label = { Text(if (isTopDown) "1-2-3" else "7-8-9", fontSize = 11.sp) },
                            modifier = Modifier.testTag("keypad_order_toggle")
                        )
                        FilterChip(
                            selected = angleUnit == HighPrecisionEvaluator.AngleUnit.RADIANS,
                            onClick = {
                                haptics.tick()
                                angleUnit = if (angleUnit == HighPrecisionEvaluator.AngleUnit.DEGREES)
                                    HighPrecisionEvaluator.AngleUnit.RADIANS
                                else HighPrecisionEvaluator.AngleUnit.DEGREES
                            },
                            label = { Text(if (angleUnit == HighPrecisionEvaluator.AngleUnit.DEGREES) "DEG" else "RAD", fontSize = 11.sp) },
                            modifier = Modifier.testTag("angle_toggle")
                        )
                        IconButton(
                            onClick = {
                                haptics.tick()
                                isScientificExpanded = !isScientificExpanded
                            },
                            modifier = Modifier.size(32.dp).testTag("toggle_scientific_drawer")
                        ) {
                            Icon(
                                if (isScientificExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Toggle Scientific Functions"
                            )
                        }
                    }
                }

                // Expandable Scientific Drawer
                AnimatedVisibility(visible = isScientificExpanded) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            KeyButton("sin", Modifier.weight(1f)) { appendInput("sin(") }
                            KeyButton("cos", Modifier.weight(1f)) { appendInput("cos(") }
                            KeyButton("tan", Modifier.weight(1f)) { appendInput("tan(") }
                            KeyButton("π", Modifier.weight(1f)) { appendInput("π") }
                            KeyButton("e", Modifier.weight(1f)) { appendInput("e") }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            KeyButton("ln", Modifier.weight(1f)) { appendInput("ln(") }
                            KeyButton("log", Modifier.weight(1f)) { appendInput("log(") }
                            KeyButton("√", Modifier.weight(1f)) { appendInput("sqrt(") }
                            KeyButton("^", Modifier.weight(1f)) { appendInput("^") }
                            KeyButton("!", Modifier.weight(1f)) { appendInput("!") }
                        }
                    }
                }

                // Standard 4x5 Keypad Grid (Supports Top-Down "1-2-3" or Classic "7-8-9")
                val isTopDownOrder = settings.keypadOrder == KeypadOrder.TOP_DOWN
                val numRow1 = if (isTopDownOrder) listOf("1", "2", "3") else listOf("7", "8", "9")
                val numRow2 = listOf("4", "5", "6")
                val numRow3 = if (isTopDownOrder) listOf("7", "8", "9") else listOf("1", "2", "3")

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        KeyButton("C", Modifier.weight(1f), containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer) { onClear() }
                        KeyButton("(", Modifier.weight(1f)) { appendInput("(") }
                        KeyButton(")", Modifier.weight(1f)) { appendInput(")") }
                        KeyButton("⌫", Modifier.weight(1f)) { onBackspace() }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        KeyButton(numRow1[0], Modifier.weight(1f), isNumber = true) { appendInput(numRow1[0]) }
                        KeyButton(numRow1[1], Modifier.weight(1f), isNumber = true) { appendInput(numRow1[1]) }
                        KeyButton(numRow1[2], Modifier.weight(1f), isNumber = true) { appendInput(numRow1[2]) }
                        KeyButton("÷", Modifier.weight(1f), containerColor = MaterialTheme.colorScheme.secondaryContainer) { appendInput("÷") }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        KeyButton(numRow2[0], Modifier.weight(1f), isNumber = true) { appendInput(numRow2[0]) }
                        KeyButton(numRow2[1], Modifier.weight(1f), isNumber = true) { appendInput(numRow2[1]) }
                        KeyButton(numRow2[2], Modifier.weight(1f), isNumber = true) { appendInput(numRow2[2]) }
                        KeyButton("×", Modifier.weight(1f), containerColor = MaterialTheme.colorScheme.secondaryContainer) { appendInput("×") }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        KeyButton(numRow3[0], Modifier.weight(1f), isNumber = true) { appendInput(numRow3[0]) }
                        KeyButton(numRow3[1], Modifier.weight(1f), isNumber = true) { appendInput(numRow3[1]) }
                        KeyButton(numRow3[2], Modifier.weight(1f), isNumber = true) { appendInput(numRow3[2]) }
                        KeyButton("-", Modifier.weight(1f), containerColor = MaterialTheme.colorScheme.secondaryContainer) { appendInput("-") }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        KeyButton("0", Modifier.weight(1f), isNumber = true) { appendInput("0") }
                        KeyButton(".", Modifier.weight(1f), isNumber = true) { appendInput(".") }
                        KeyButton("%", Modifier.weight(1f)) { appendInput("%") }
                        KeyButton("+", Modifier.weight(1f), containerColor = MaterialTheme.colorScheme.secondaryContainer) { appendInput("+") }
                    }
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { onEquals() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .testTag("btn_equals"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("=", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            1 -> {
                // DISCOUNT CALCULATOR
                DiscountCalculatorView(repository, haptics)
            }

            2 -> {
                // TALLY COUNTER
                TallyCounterView(haptics)
            }
        }
    }
}

@Composable
private fun KeyButton(
    text: String,
    modifier: Modifier = Modifier,
    isNumber: Boolean = false,
    containerColor: Color? = null,
    contentColor: Color? = null,
    onClick: () -> Unit
) {
    val bgColor = containerColor ?: if (isNumber) {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
    }

    val textColor = contentColor ?: if (isNumber) {
        MaterialTheme.colorScheme.onSurface
    } else {
        MaterialTheme.colorScheme.primary
    }

    FilledTonalButton(
        onClick = onClick,
        modifier = modifier
            .height(52.dp)
            .testTag("btn_$text"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.filledTonalButtonColors(
            containerColor = bgColor,
            contentColor = textColor
        ),
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = if (isNumber) FontWeight.Normal else FontWeight.Bold
            )
        )
    }
}

@Composable
fun DiscountCalculatorView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var originalPriceStr by remember { mutableStateOf("100") }
    var discountPercentStr by remember { mutableStateOf("20") }
    var salesTaxPercentStr by remember { mutableStateOf("8") }

    val coroutineScope = rememberCoroutineScope()

    val original = originalPriceStr.toDoubleOrNull() ?: 0.0
    val discountPct = discountPercentStr.toDoubleOrNull() ?: 0.0
    val taxPct = salesTaxPercentStr.toDoubleOrNull() ?: 0.0

    val savings = original * (discountPct / 100.0)
    val discountedPrice = original - savings
    val taxAmount = discountedPrice * (taxPct / 100.0)
    val finalPrice = discountedPrice + taxAmount

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Final Price", style = MaterialTheme.typography.labelMedium)
                Text(
                    "$${String.format("%.2f", finalPrice)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "You save $${String.format("%.2f", savings)} ($discountPct%)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        OutlinedTextField(
            value = originalPriceStr,
            onValueChange = { originalPriceStr = it },
            label = { Text("Original Price ($)") },
            modifier = Modifier.fillMaxWidth().testTag("discount_orig_price")
        )
        OutlinedTextField(
            value = discountPercentStr,
            onValueChange = { discountPercentStr = it },
            label = { Text("Discount Percentage (%)") },
            modifier = Modifier.fillMaxWidth().testTag("discount_percent")
        )
        OutlinedTextField(
            value = salesTaxPercentStr,
            onValueChange = { salesTaxPercentStr = it },
            label = { Text("Sales Tax (%)") },
            modifier = Modifier.fillMaxWidth().testTag("discount_tax")
        )

        Button(
            onClick = {
                haptics.heavyTick()
                coroutineScope.launch {
                    repository.saveCalculation(
                        category = "Standard",
                        calculatorName = "Percentage & Discount",
                        expression = "Price: $$original, -$discountPct% off, +$taxPct% tax",
                        result = "Final: $${String.format("%.2f", finalPrice)}"
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("save_discount_btn")
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Save Calculation")
        }
    }
}

@Composable
fun TallyCounterView(haptics: HapticFeedbackManager) {
    var count by remember { mutableStateOf(0) }
    var stepSize by remember { mutableStateOf(1) }
    var label by remember { mutableStateOf("General Counter") }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        OutlinedTextField(
            value = label,
            onValueChange = { label = it },
            label = { Text("Counter Label") },
            modifier = Modifier.fillMaxWidth(0.8f).testTag("tally_label_input")
        )

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            modifier = Modifier.size(200.dp),
            shape = CircleShape,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                Text(
                    text = count.toString(),
                    style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("tally_count_text")
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalIconButton(
                onClick = {
                    haptics.tick()
                    count = (count - stepSize).coerceAtLeast(0)
                },
                modifier = Modifier.size(64.dp).testTag("tally_decrement")
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Decrement", modifier = Modifier.size(32.dp))
            }

            FilledIconButton(
                onClick = {
                    haptics.heavyTick()
                    count += stepSize
                },
                modifier = Modifier.size(80.dp).testTag("tally_increment")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Increment", modifier = Modifier.size(40.dp))
            }

            FilledTonalIconButton(
                onClick = {
                    haptics.tick()
                    count = 0
                },
                modifier = Modifier.size(64.dp).testTag("tally_reset")
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = "Reset", modifier = Modifier.size(32.dp))
            }
        }
    }
}
