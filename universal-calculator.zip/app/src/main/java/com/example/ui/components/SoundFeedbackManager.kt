package com.example.ui.components

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import java.io.File
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Manages crisp, tactile calculator button audio clicks.
 * Uses direct in-memory PCM synthesis via AudioTrack and system AudioManager
 * without file I/O or media codecs to prevent system resource errors in container environments.
 */
class SoundFeedbackManager(
    private val context: Context,
    var soundEnabled: Boolean
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private var clickTrack: AudioTrack? = null
    private var heavyClickTrack: AudioTrack? = null
    private var backspaceTrack: AudioTrack? = null

    init {
        cleanupOldCacheFiles()
        initTracks()
    }

    private fun cleanupOldCacheFiles() {
        try {
            listOf("calc_click.wav", "calc_heavy_click.wav", "calc_backspace.wav").forEach { fileName ->
                val f = File(context.cacheDir, fileName)
                if (f.exists()) f.delete()
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun initTracks() {
        try {
            clickTrack = createStaticTrack(frequency = 1300.0, durationMs = 12, decay = 6.0)
            heavyClickTrack = createStaticTrack(frequency = 850.0, durationMs = 18, decay = 5.0)
            backspaceTrack = createStaticTrack(frequency = 1050.0, durationMs = 15, decay = 5.5)
        } catch (e: Exception) {
            // Ignore - fallback to AudioManager.playSoundEffect
        }
    }

    private fun createStaticTrack(
        frequency: Double,
        durationMs: Int,
        decay: Double
    ): AudioTrack? {
        return try {
            val sampleRate = 22050
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val pcmData = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val envelope = exp(-decay * (i.toDouble() / numSamples))
                val sample = (sin(2.0 * PI * frequency * t) * envelope * 22000.0).toInt()
                pcmData[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            val track = AudioTrack.Builder()
                .setAudioAttributes(attributes)
                .setAudioFormat(format)
                .setBufferSizeInBytes(numSamples * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(pcmData, 0, numSamples)
            track
        } catch (e: Exception) {
            null
        }
    }

    private fun playTrack(track: AudioTrack?, fallbackFx: Int) {
        if (!soundEnabled) return
        var played = false
        try {
            track?.let {
                if (it.state == AudioTrack.STATE_INITIALIZED) {
                    if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                        it.stop()
                    }
                    it.reloadStaticData()
                    it.play()
                    played = true
                }
            }
        } catch (e: Exception) {
            played = false
        }

        if (!played) {
            try {
                audioManager?.playSoundEffect(fallbackFx, 0.85f)
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    fun playClick() {
        playTrack(clickTrack, AudioManager.FX_KEY_CLICK)
    }

    fun playHeavyClick() {
        playTrack(heavyClickTrack, AudioManager.FX_KEYPRESS_STANDARD)
    }

    fun playBackspace() {
        playTrack(backspaceTrack, AudioManager.FX_KEYPRESS_DELETE)
    }

    fun release() {
        try {
            clickTrack?.release()
            clickTrack = null
            heavyClickTrack?.release()
            heavyClickTrack = null
            backspaceTrack?.release()
            backspaceTrack = null
        } catch (e: Exception) {
            // Ignore
        }
    }
}

@Composable
fun rememberSoundFeedback(enabled: Boolean): SoundFeedbackManager {
    val context = LocalContext.current
    val manager = remember(context) {
        SoundFeedbackManager(context, enabled)
    }
    manager.soundEnabled = enabled

    DisposableEffect(manager) {
        onDispose {
            manager.release()
        }
    }
    return manager
}

