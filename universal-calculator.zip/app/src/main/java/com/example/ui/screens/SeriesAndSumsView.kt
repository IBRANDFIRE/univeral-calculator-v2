package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.CalcRepository
import com.example.engine.StudentMathSolver
import com.example.ui.components.HapticFeedbackManager

@Composable
fun SeriesAndSumsView(
    repository: CalcRepository,
    haptics: HapticFeedbackManager,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableStateOf(0) }
    val tabs = listOf("Arithmetic Prog (AP)", "Geometric Prog (GP)", "Summation Σ f(k)")

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("series_and_sums_view")
    ) {
        TabRow(
            selectedTabIndex = selectedSubTab,
            modifier = Modifier.fillMaxWidth().testTag("series_tab_row")
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = {
                        haptics.tick()
                        selectedSubTab = index
                    },
                    text = { Text(title) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSubTab) {
                0 -> APSolverView(repository, haptics)
                1 -> GPSolverView(repository, haptics)
                2 -> SigmaSummationView(repository, haptics)
            }
        }
    }
}

@Composable
fun APSolverView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var aStr by remember { mutableStateOf("2") }
    var dStr by remember { mutableStateOf("5") }
    var nStr by remember { mutableStateOf("10") }
    var apResult by remember { mutableStateOf<StudentMathSolver.APResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Arithmetic Progression (AP) Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Formula: aₙ = a + (n - 1)d,   Sₙ = (n/2)[2a + (n - 1)d]", style = MaterialTheme.typography.bodySmall)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = aStr, onValueChange = { aStr = it }, label = { Text("First Term (a)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = dStr, onValueChange = { dStr = it }, label = { Text("Common Diff (d)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = nStr, onValueChange = { nStr = it }, label = { Text("No. of Terms (n)") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val a = aStr.toDoubleOrNull() ?: 0.0
                val d = dStr.toDoubleOrNull() ?: 1.0
                val n = nStr.toIntOrNull() ?: 10
                apResult = StudentMathSolver.calculateAP(a, d, n)
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_ap")
        ) {
            Text("Calculate AP Sum & n-th Term")
        }

        apResult?.let { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("a_n (n-th Term) = ${StudentMathSolver.formatNum(res.nthTerm)}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("S_n (Sum of $nStr terms) = ${StudentMathSolver.formatNum(res.sumN)}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)

                    HorizontalDivider()
                    Text("Sequence Preview:", style = MaterialTheme.typography.labelMedium)
                    Text(res.sequencePreview.joinToString(", ") { StudentMathSolver.formatNum(it) } + " ...", style = MaterialTheme.typography.bodyMedium)

                    HorizontalDivider()
                    Text("Step-by-Step Explanation:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    res.steps.forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun GPSolverView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var aStr by remember { mutableStateOf("3") }
    var rStr by remember { mutableStateOf("2") }
    var nStr by remember { mutableStateOf("8") }
    var gpResult by remember { mutableStateOf<StudentMathSolver.GPResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Geometric Progression (GP) Calculator", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Formula: aₙ = a × rⁿ⁻¹,   Sₙ = a(rⁿ - 1)/(r - 1),   S_∞ = a / (1 - r)", style = MaterialTheme.typography.bodySmall)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = aStr, onValueChange = { aStr = it }, label = { Text("First Term (a)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = rStr, onValueChange = { rStr = it }, label = { Text("Common Ratio (r)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = nStr, onValueChange = { nStr = it }, label = { Text("Terms (n)") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val a = aStr.toDoubleOrNull() ?: 1.0
                val r = rStr.toDoubleOrNull() ?: 2.0
                val n = nStr.toIntOrNull() ?: 5
                gpResult = StudentMathSolver.calculateGP(a, r, n)
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_gp")
        ) {
            Text("Calculate GP Sum & Terms")
        }

        gpResult?.let { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("a_n (n-th Term) = ${StudentMathSolver.formatNum(res.nthTerm)}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("S_n (Sum of $nStr terms) = ${StudentMathSolver.formatNum(res.sumN)}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    res.infiniteSum?.let { infSum ->
                        Text("S_∞ (Infinite Sum) = ${StudentMathSolver.formatNum(infSum)}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                    }

                    HorizontalDivider()
                    Text("Sequence Preview:", style = MaterialTheme.typography.labelMedium)
                    Text(res.sequencePreview.joinToString(", ") { StudentMathSolver.formatNum(it) } + " ...", style = MaterialTheme.typography.bodyMedium)

                    HorizontalDivider()
                    res.steps.forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun SigmaSummationView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var expr by remember { mutableStateOf("k^2 + 2*k") }
    var kStartStr by remember { mutableStateOf("1") }
    var kEndStr by remember { mutableStateOf("10") }
    var sumResult by remember { mutableStateOf<StudentMathSolver.SeriesSumResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Summation Σ_{k=a}^{b} f(k)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Enter expression in variable 'k' (e.g., k, k^2, k^3, 2*k + 1, 2^k)", style = MaterialTheme.typography.bodySmall)
            }
        }

        OutlinedTextField(
            value = expr,
            onValueChange = { expr = it },
            label = { Text("Function f(k)") },
            leadingIcon = { Icon(Icons.Default.Functions, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().testTag("input_sigma_expr")
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = kStartStr, onValueChange = { kStartStr = it }, label = { Text("Start k") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = kEndStr, onValueChange = { kEndStr = it }, label = { Text("End k") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val kStart = kStartStr.toIntOrNull() ?: 1
                val kEnd = kEndStr.toIntOrNull() ?: 10
                sumResult = StudentMathSolver.calculateSeriesSum(expr, kStart, kEnd)
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_sigma")
        ) {
            Text("Calculate Sum Σ f(k)")
        }

        sumResult?.let { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Summation Result: Σ = ${StudentMathSolver.formatNum(res.sumValue)}", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)

                    res.formulaName?.let { fName ->
                        Text("Formula Recognized: $fName", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary)
                    }

                    HorizontalDivider()
                    Text("First Terms Evaluated:", style = MaterialTheme.typography.labelMedium)
                    Text(res.terms.joinToString(" + ") { StudentMathSolver.formatNum(it) } + if (res.terms.size >= 15) " + ..." else "", style = MaterialTheme.typography.bodyMedium)

                    HorizontalDivider()
                    res.steps.forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
