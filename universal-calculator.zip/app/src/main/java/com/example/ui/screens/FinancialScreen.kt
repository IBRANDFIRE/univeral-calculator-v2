package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CalcRepository
import com.example.engine.FinancialCalculators
import com.example.ui.components.HapticFeedbackManager
import kotlinx.coroutines.launch

@Composable
fun FinancialScreen(
    repository: CalcRepository,
    haptics: HapticFeedbackManager,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(initialTab) }
    LaunchedEffect(initialTab) {
        selectedTab = initialTab
    }
    val tabs = listOf("Loan EMI", "SIP / Compound", "Currency", "Tip Splitter", "Tax & VAT", "Margin & BE", "Retirement")

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("financial_screen")
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 8.dp,
            modifier = Modifier.fillMaxWidth().testTag("financial_tab_row")
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = {
                        haptics.tick()
                        selectedTab = index
                    },
                    text = { Text(title) },
                    modifier = Modifier.testTag("fin_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTab) {
            0 -> LoanEmiView(repository, haptics)
            1 -> SipCompoundView(repository, haptics)
            2 -> CurrencyConverterView(repository, haptics)
            3 -> TipSplitterView(repository, haptics)
            4 -> TaxVatView(repository, haptics)
            5 -> MarginBreakEvenView(repository, haptics)
            6 -> RetirementPlannerView(repository, haptics)
        }
    }
}

@Composable
fun LoanEmiView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var principalStr by remember { mutableStateOf("250000") }
    var interestRateStr by remember { mutableStateOf("6.5") }
    var tenureYearsStr by remember { mutableStateOf("15") }
    var showAmortization by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    val principal = principalStr.toDoubleOrNull() ?: 0.0
    val rate = interestRateStr.toDoubleOrNull() ?: 0.0
    val tenure = tenureYearsStr.toDoubleOrNull() ?: 0.0

    val emiResult = remember(principal, rate, tenure) {
        FinancialCalculators.calculateLoanEmi(principal, rate, tenure)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Monthly EMI Payment", style = MaterialTheme.typography.labelMedium)
                Text(
                    "$${String.format("%,.2f", emiResult.monthlyEmi)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Total Interest", style = MaterialTheme.typography.labelSmall)
                        Text("$${String.format("%,.0f", emiResult.totalInterest)}", fontWeight = FontWeight.SemiBold)
                    }
                    Column {
                        Text("Total Payment", style = MaterialTheme.typography.labelSmall)
                        Text("$${String.format("%,.0f", emiResult.totalPayment)}", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        OutlinedTextField(
            value = principalStr,
            onValueChange = { principalStr = it },
            label = { Text("Loan Principal Amount ($)") },
            modifier = Modifier.fillMaxWidth().testTag("emi_principal_input")
        )
        OutlinedTextField(
            value = interestRateStr,
            onValueChange = { interestRateStr = it },
            label = { Text("Annual Interest Rate (%)") },
            modifier = Modifier.fillMaxWidth().testTag("emi_rate_input")
        )
        OutlinedTextField(
            value = tenureYearsStr,
            onValueChange = { tenureYearsStr = it },
            label = { Text("Loan Tenure (Years)") },
            modifier = Modifier.fillMaxWidth().testTag("emi_tenure_input")
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    haptics.tick()
                    showAmortization = !showAmortization
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(if (showAmortization) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (showAmortization) "Hide Schedule" else "Amortization Table")
            }

            FilledTonalButton(
                onClick = {
                    haptics.heavyTick()
                    coroutineScope.launch {
                        repository.saveCalculation(
                            category = "Financial",
                            calculatorName = "Loan EMI",
                            expression = "P: $$principal, $rate% for $tenure yrs",
                            result = "EMI: $${String.format("%,.2f", emiResult.monthlyEmi)}/mo",
                            details = "Total Interest: $${String.format("%,.0f", emiResult.totalInterest)}"
                        )
                    }
                }
            ) {
                Icon(Icons.Default.Save, contentDescription = null)
            }
        }

        if (showAmortization && emiResult.amortizationSchedule.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text("Amortization Schedule (First 24 months)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Mo", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text("Principal", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text("Interest", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        Text("Balance", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                    }
                    HorizontalDivider()
                    emiResult.amortizationSchedule.take(24).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${row.month}", style = MaterialTheme.typography.bodySmall)
                            Text("$${row.principalPaid.toInt()}", style = MaterialTheme.typography.bodySmall)
                            Text("$${row.interestPaid.toInt()}", style = MaterialTheme.typography.bodySmall)
                            Text("$${row.remainingBalance.toInt()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SipCompoundView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var monthlyDepositStr by remember { mutableStateOf("500") }
    var expectedReturnStr by remember { mutableStateOf("12") }
    var tenureYearsStr by remember { mutableStateOf("10") }

    val deposit = monthlyDepositStr.toDoubleOrNull() ?: 0.0
    val ret = expectedReturnStr.toDoubleOrNull() ?: 0.0
    val tenure = tenureYearsStr.toIntOrNull() ?: 0

    val sipResult = remember(deposit, ret, tenure) {
        FinancialCalculators.calculateSip(deposit, ret, tenure)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Total Expected Maturity Corpus", style = MaterialTheme.typography.labelMedium)
                Text(
                    "$${String.format("%,.0f", sipResult.totalMaturity)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Amount Invested", style = MaterialTheme.typography.labelSmall)
                        Text("$${String.format("%,.0f", sipResult.totalInvested)}", fontWeight = FontWeight.SemiBold)
                    }
                    Column {
                        Text("Wealth Gained", style = MaterialTheme.typography.labelSmall)
                        Text("+$${String.format("%,.0f", sipResult.wealthGained)}", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }

        OutlinedTextField(
            value = monthlyDepositStr,
            onValueChange = { monthlyDepositStr = it },
            label = { Text("Monthly Investment ($)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = expectedReturnStr,
            onValueChange = { expectedReturnStr = it },
            label = { Text("Expected Annual Return (%)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = tenureYearsStr,
            onValueChange = { tenureYearsStr = it },
            label = { Text("Time Period (Years)") },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurrencyConverterView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var amountStr by remember { mutableStateOf("100") }
    var fromCurrency by remember { mutableStateOf("USD") }
    var toCurrency by remember { mutableStateOf("EUR") }

    val amount = amountStr.toDoubleOrNull() ?: 0.0
    val converted = FinancialCalculators.convertCurrency(amount, fromCurrency, toCurrency)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Converted Amount", style = MaterialTheme.typography.labelMedium)
                Text(
                    "${String.format("%,.2f", converted)} $toCurrency",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "1 $fromCurrency = ${String.format("%.4f", FinancialCalculators.convertCurrency(1.0, fromCurrency, toCurrency))} $toCurrency",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        OutlinedTextField(
            value = amountStr,
            onValueChange = { amountStr = it },
            label = { Text("Amount") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CurrencyDropdown(fromCurrency, Modifier.weight(1f)) { fromCurrency = it }
            IconButton(
                onClick = {
                    haptics.tick()
                    val temp = fromCurrency
                    fromCurrency = toCurrency
                    toCurrency = temp
                }
            ) {
                Icon(Icons.Default.SwapHoriz, contentDescription = "Swap")
            }
            CurrencyDropdown(toCurrency, Modifier.weight(1f)) { toCurrency = it }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurrencyDropdown(selectedCode: String, modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = selectedCode,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            FinancialCalculators.DEFAULT_CURRENCIES.forEach { curr ->
                DropdownMenuItem(
                    text = { Text("${curr.code} - ${curr.name}") },
                    onClick = {
                        onSelect(curr.code)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun TipSplitterView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var billAmountStr by remember { mutableStateOf("85.50") }
    var tipPercent by remember { mutableStateOf(15.0) }
    var splitPeople by remember { mutableStateOf(3) }

    val bill = billAmountStr.toDoubleOrNull() ?: 0.0
    val tipResult = FinancialCalculators.calculateTip(bill, tipPercent, splitPeople)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Per Person Total", style = MaterialTheme.typography.labelMedium)
                Text(
                    "$${String.format("%.2f", tipResult.perPersonTotal)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Total Bill: $${String.format("%.2f", tipResult.totalAmount)} (Tip: $${String.format("%.2f", tipResult.tipAmount)})",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        OutlinedTextField(
            value = billAmountStr,
            onValueChange = { billAmountStr = it },
            label = { Text("Bill Amount ($)") },
            modifier = Modifier.fillMaxWidth()
        )

        Text("Tip Percentage: ${tipPercent.toInt()}%", style = MaterialTheme.typography.labelMedium)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(10.0, 15.0, 18.0, 20.0, 25.0).forEach { pct ->
                FilterChip(
                    selected = tipPercent == pct,
                    onClick = {
                        haptics.tick()
                        tipPercent = pct
                    },
                    label = { Text("${pct.toInt()}%") }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Split between: $splitPeople people", style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilledTonalIconButton(
                    onClick = {
                        haptics.tick()
                        splitPeople = (splitPeople - 1).coerceAtLeast(1)
                    }
                ) {
                    Icon(Icons.Default.Remove, contentDescription = null)
                }
                FilledTonalIconButton(
                    onClick = {
                        haptics.tick()
                        splitPeople += 1
                    }
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                }
            }
        }
    }
}

@Composable
fun TaxVatView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var amountStr by remember { mutableStateOf("100") }
    var taxRateStr by remember { mutableStateOf("7.5") }
    var isTaxInclusive by remember { mutableStateOf(false) }

    val amount = amountStr.toDoubleOrNull() ?: 0.0
    val rate = taxRateStr.toDoubleOrNull() ?: 0.0
    val result = FinancialCalculators.calculateTax(amount, rate, isTaxInclusive)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(if (isTaxInclusive) "Net (Pre-tax) Amount" else "Gross (Total) Amount", style = MaterialTheme.typography.labelMedium)
                Text(
                    "$${String.format("%.2f", if (isTaxInclusive) result.netAmount else result.grossAmount)}",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text("Tax amount: $${String.format("%.2f", result.taxAmount)}")
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Price is Tax Inclusive", modifier = Modifier.align(Alignment.CenterVertically))
            Switch(checked = isTaxInclusive, onCheckedChange = { isTaxInclusive = it })
        }

        OutlinedTextField(
            value = amountStr,
            onValueChange = { amountStr = it },
            label = { Text("Amount ($)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = taxRateStr,
            onValueChange = { taxRateStr = it },
            label = { Text("Tax Rate (%)") },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun MarginBreakEvenView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var costStr by remember { mutableStateOf("40") }
    var revenueStr by remember { mutableStateOf("60") }

    val cost = costStr.toDoubleOrNull() ?: 0.0
    val rev = revenueStr.toDoubleOrNull() ?: 0.0
    val marginRes = FinancialCalculators.calculateMargin(cost, rev)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Profit & Margins", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Gross Profit: $${String.format("%.2f", marginRes.profit)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                Text("Profit Margin: ${String.format("%.2f", marginRes.marginPercent)}%")
                Text("Markup on Cost: ${String.format("%.2f", marginRes.markupPercent)}%")
            }
        }

        OutlinedTextField(
            value = costStr,
            onValueChange = { costStr = it },
            label = { Text("Cost of Goods ($)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = revenueStr,
            onValueChange = { revenueStr = it },
            label = { Text("Selling Price / Revenue ($)") },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun RetirementPlannerView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var currentAgeStr by remember { mutableStateOf("30") }
    var retirementAgeStr by remember { mutableStateOf("65") }
    var currentSavingsStr by remember { mutableStateOf("50000") }
    var desiredMonthlyStr by remember { mutableStateOf("4000") }

    val curAge = currentAgeStr.toIntOrNull() ?: 30
    val retAge = retirementAgeStr.toIntOrNull() ?: 65
    val savings = currentSavingsStr.toDoubleOrNull() ?: 0.0
    val desired = desiredMonthlyStr.toDoubleOrNull() ?: 0.0

    val retResult = FinancialCalculators.calculateRetirement(
        currentAge = curAge,
        retirementAge = retAge,
        currentSavings = savings,
        monthlyContribution = 500.0,
        expectedReturnRate = 7.0,
        desiredMonthlyPension = desired
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Target Retirement Corpus", style = MaterialTheme.typography.labelMedium)
                Text(
                    "$${String.format("%,.0f", retResult.targetCorpus)}",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text("Required Monthly Savings: $${String.format("%,.0f", retResult.requiredMonthlySavings)}/mo")
            }
        }

        OutlinedTextField(value = currentAgeStr, onValueChange = { currentAgeStr = it }, label = { Text("Current Age") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = retirementAgeStr, onValueChange = { retirementAgeStr = it }, label = { Text("Target Retirement Age") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = currentSavingsStr, onValueChange = { currentSavingsStr = it }, label = { Text("Current Savings ($)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = desiredMonthlyStr, onValueChange = { desiredMonthlyStr = it }, label = { Text("Desired Monthly Pension ($)") }, modifier = Modifier.fillMaxWidth())
    }
}
