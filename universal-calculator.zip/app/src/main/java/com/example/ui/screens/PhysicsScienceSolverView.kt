package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CalcRepository
import com.example.engine.PhysicsScienceSolver
import com.example.ui.components.HapticFeedbackManager
import kotlinx.coroutines.launch

@Composable
fun PhysicsScienceSolverView(
    repository: CalcRepository,
    haptics: HapticFeedbackManager,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableStateOf(0) }
    val tabs = listOf("Kinematics & Motion", "Work, Power & Gravity", "Electricity & Circuits", "Optics & Waves", "Modern Physics")

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("physics_science_solver_view")
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            edgePadding = 4.dp,
            modifier = Modifier.fillMaxWidth().testTag("physics_tab_row")
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = {
                        haptics.tick()
                        selectedSubTab = index
                    },
                    text = { Text(title, fontSize = 12.sp) },
                    modifier = Modifier.testTag("phys_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSubTab) {
                0 -> KinematicsMotionView(repository, haptics)
                1 -> WorkPowerGravityView(repository, haptics)
                2 -> ElectricityCircuitsView(repository, haptics)
                3 -> OpticsWavesView(repository, haptics)
                4 -> ModernPhysicsView(repository, haptics)
            }
        }
    }
}

@Composable
fun KinematicsMotionView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var isProjectile by remember { mutableStateOf(false) }

    // 1D Kinematics inputs
    var uStr by remember { mutableStateOf("0") }
    var vStr by remember { mutableStateOf("20") }
    var aStr by remember { mutableStateOf("9.81") }
    var tStr by remember { mutableStateOf("") }
    var sStr by remember { mutableStateOf("") }

    // Projectile inputs
    var projUStr by remember { mutableStateOf("30") }
    var projAngleStr by remember { mutableStateOf("45") }

    var result by remember { mutableStateOf<PhysicsScienceSolver.PhysicsResult?>(null) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !isProjectile,
                onClick = { isProjectile = false },
                label = { Text("1D Equations of Motion") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = isProjectile,
                onClick = { isProjectile = true },
                label = { Text("Projectile Motion (2D)") },
                modifier = Modifier.weight(1f)
            )
        }

        if (!isProjectile) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🚀 1D Motion Solver (Std 9 & 11)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Leave any 1 or 2 fields blank to solve them automatically using Newton's laws of motion", style = MaterialTheme.typography.bodySmall)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = uStr, onValueChange = { uStr = it }, label = { Text("u (m/s)") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = vStr, onValueChange = { vStr = it }, label = { Text("v (m/s)") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = aStr, onValueChange = { aStr = it }, label = { Text("a (m/s²)") }, modifier = Modifier.weight(1f))
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = tStr, onValueChange = { tStr = it }, label = { Text("t (s)") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = sStr, onValueChange = { sStr = it }, label = { Text("s (m)") }, modifier = Modifier.weight(1f))
            }

            Button(
                onClick = {
                    haptics.heavyTick()
                    val res = PhysicsScienceSolver.solveKinematics(
                        uStr.toDoubleOrNull(),
                        vStr.toDoubleOrNull(),
                        aStr.toDoubleOrNull(),
                        tStr.toDoubleOrNull(),
                        sStr.toDoubleOrNull()
                    )
                    result = res
                    coroutineScope.launch {
                        repository.saveCalculation("Physics", "Kinematics", "1D Motion", res.valuesMap.toString())
                    }
                },
                modifier = Modifier.fillMaxWidth().testTag("btn_solve_kinematics")
            ) {
                Text("Solve Motion Parameters")
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("🎯 Projectile Motion Solver (Std 11)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Calculates Time of Flight (T), Maximum Height (H), and Range (R)", style = MaterialTheme.typography.bodySmall)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = projUStr, onValueChange = { projUStr = it }, label = { Text("Velocity u (m/s)") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = projAngleStr, onValueChange = { projAngleStr = it }, label = { Text("Angle θ (°)") }, modifier = Modifier.weight(1f))
            }

            Button(
                onClick = {
                    haptics.heavyTick()
                    val u = projUStr.toDoubleOrNull() ?: 20.0
                    val angle = projAngleStr.toDoubleOrNull() ?: 45.0
                    val res = PhysicsScienceSolver.solveProjectile(u, angle)
                    result = res
                    coroutineScope.launch {
                        repository.saveCalculation("Physics", "Projectile", "u=$u, θ=$angle°", "Range: ${res.valuesMap["Horizontal Range (R)"]}")
                    }
                },
                modifier = Modifier.fillMaxWidth().testTag("btn_solve_projectile")
            ) {
                Text("Calculate Projectile Trajectory")
            }
        }

        result?.let { res ->
            PhysicsResultDisplayCard(res)
        }
    }
}

@Composable
fun WorkPowerGravityView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var massStr by remember { mutableStateOf("10") }
    var velStr by remember { mutableStateOf("15") }
    var heightStr by remember { mutableStateOf("25") }
    var forceStr by remember { mutableStateOf("100") }
    var distStr by remember { mutableStateOf("50") }
    var timeStr by remember { mutableStateOf("5") }

    var result by remember { mutableStateOf<PhysicsScienceSolver.PhysicsResult?>(null) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("⚡ Work, Kinetic/Potential Energy & Gravitation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("KE = ½mv², PE = mgh, Power P = W/t, Universal Gravitation F = GMm/r²", style = MaterialTheme.typography.bodySmall)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = massStr, onValueChange = { massStr = it }, label = { Text("Mass m (kg)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = velStr, onValueChange = { velStr = it }, label = { Text("Velocity v (m/s)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = heightStr, onValueChange = { heightStr = it }, label = { Text("Height h (m)") }, modifier = Modifier.weight(1f))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = forceStr, onValueChange = { forceStr = it }, label = { Text("Force F (N)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = distStr, onValueChange = { distStr = it }, label = { Text("Distance d (m)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = timeStr, onValueChange = { timeStr = it }, label = { Text("Time t (s)") }, modifier = Modifier.weight(1f))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    haptics.heavyTick()
                    val res = PhysicsScienceSolver.solveWorkEnergyPower(
                        massStr.toDoubleOrNull(),
                        velStr.toDoubleOrNull(),
                        heightStr.toDoubleOrNull(),
                        forceStr.toDoubleOrNull(),
                        distStr.toDoubleOrNull(),
                        timeStr.toDoubleOrNull()
                    )
                    result = res
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Calculate W, E & P")
            }

            Button(
                onClick = {
                    haptics.heavyTick()
                    val m1 = massStr.toDoubleOrNull() ?: 5.972e24 // Earth
                    val m2 = forceStr.toDoubleOrNull() ?: 1000.0   // Satellite
                    val r = distStr.toDoubleOrNull() ?: 6.371e6   // Radius
                    val res = PhysicsScienceSolver.solveGravitation(m1, m2, r)
                    result = res
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Gravitation & Escape V")
            }
        }

        result?.let { res ->
            PhysicsResultDisplayCard(res)
        }
    }
}

@Composable
fun ElectricityCircuitsView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var vStr by remember { mutableStateOf("220") }
    var iStr by remember { mutableStateOf("5") }
    var rStr by remember { mutableStateOf("") }
    var resistorsCsv by remember { mutableStateOf("10, 20, 30") }
    var isSeries by remember { mutableStateOf(true) }

    var result by remember { mutableStateOf<PhysicsScienceSolver.PhysicsResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("💡 Electricity, Ohm's Law & Circuits (Std 10 & 12)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("V = IR, Power P = VI, Equivalent Resistance in Series & Parallel", style = MaterialTheme.typography.bodySmall)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = vStr, onValueChange = { vStr = it }, label = { Text("Voltage V (Volts)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = iStr, onValueChange = { iStr = it }, label = { Text("Current I (Amps)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = rStr, onValueChange = { rStr = it }, label = { Text("Resistance R (Ω)") }, modifier = Modifier.weight(1f))
        }

        OutlinedTextField(
            value = resistorsCsv,
            onValueChange = { resistorsCsv = it },
            label = { Text("Resistor Values (comma separated, e.g., 10, 20, 30)") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = isSeries, onClick = { isSeries = true }, label = { Text("Series Combination (R_s)") }, modifier = Modifier.weight(1f))
            FilterChip(selected = !isSeries, onClick = { isSeries = false }, label = { Text("Parallel Combination (R_p)") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val rList = resistorsCsv.split(",").mapNotNull { it.trim().toDoubleOrNull() }
                val res = PhysicsScienceSolver.solveCircuits(
                    vStr.toDoubleOrNull(),
                    iStr.toDoubleOrNull(),
                    rStr.toDoubleOrNull(),
                    rList,
                    isSeries
                )
                result = res
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_circuits")
        ) {
            Text("Solve Circuit & Power")
        }

        result?.let { res ->
            PhysicsResultDisplayCard(res)
        }
    }
}

@Composable
fun OpticsWavesView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var uStr by remember { mutableStateOf("-20") }
    var fStr by remember { mutableStateOf("10") }
    var isMirror by remember { mutableStateOf(false) }

    var freqStr by remember { mutableStateOf("500") }
    var lambdaStr by remember { mutableStateOf("0.68") }
    var n1Str by remember { mutableStateOf("1.0") }
    var n2Str by remember { mutableStateOf("1.5") }
    var angle1Str by remember { mutableStateOf("30") }

    var result by remember { mutableStateOf<PhysicsScienceSolver.PhysicsResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("🔍 Optics, Lenses, Mirrors & Snell's Law (Std 10 & 12)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("1/f = 1/v ± 1/u, Magnification, Lens Power (D), Snell's Law n₁ sinθ₁ = n₂ sinθ₂", style = MaterialTheme.typography.bodySmall)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !isMirror, onClick = { isMirror = false }, label = { Text("Lens Formula") }, modifier = Modifier.weight(1f))
            FilterChip(selected = isMirror, onClick = { isMirror = true }, label = { Text("Mirror Formula") }, modifier = Modifier.weight(1f))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = uStr, onValueChange = { uStr = it }, label = { Text("Object dist u (cm)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = fStr, onValueChange = { fStr = it }, label = { Text("Focal length f (cm)") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val u = uStr.toDoubleOrNull() ?: -20.0
                val f = fStr.toDoubleOrNull() ?: 10.0
                val res = PhysicsScienceSolver.solveOptics(u, f, isMirror)
                result = res
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_optics")
        ) {
            Text("Solve Lens / Mirror Image")
        }

        HorizontalDivider()

        Text("Wave Speed & Snell's Law Refraction:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = freqStr, onValueChange = { freqStr = it }, label = { Text("Freq f (Hz)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = lambdaStr, onValueChange = { lambdaStr = it }, label = { Text("Wavelength λ (m)") }, modifier = Modifier.weight(1f))
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = n1Str, onValueChange = { n1Str = it }, label = { Text("Index n1") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = n2Str, onValueChange = { n2Str = it }, label = { Text("Index n2") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = angle1Str, onValueChange = { angle1Str = it }, label = { Text("Incident θ1 (°)") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val res = PhysicsScienceSolver.solveWavesAndSnell(
                    freqStr.toDoubleOrNull(),
                    lambdaStr.toDoubleOrNull(),
                    angle1Str.toDoubleOrNull(),
                    n1Str.toDoubleOrNull(),
                    n2Str.toDoubleOrNull()
                )
                result = res
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_waves")
        ) {
            Text("Solve Wave Speed & Refraction Angle")
        }

        result?.let { res ->
            PhysicsResultDisplayCard(res)
        }
    }
}

@Composable
fun ModernPhysicsView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var freqStr by remember { mutableStateOf("5e14") }
    var lambdaStr by remember { mutableStateOf("6e-7") }
    var massStr by remember { mutableStateOf("1e-27") }

    var result by remember { mutableStateOf<PhysicsScienceSolver.PhysicsResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("⚛️ Modern Physics, Photons & Relativity (Std 12)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Photon Energy E = hf = hc/λ, Mass Energy E = mc², De Broglie Wavelength λ = h/p", style = MaterialTheme.typography.bodySmall)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = freqStr, onValueChange = { freqStr = it }, label = { Text("Frequency f (Hz)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = lambdaStr, onValueChange = { lambdaStr = it }, label = { Text("Wavelength λ (m)") }, modifier = Modifier.weight(1f))
        }

        OutlinedTextField(
            value = massStr,
            onValueChange = { massStr = it },
            label = { Text("Mass m (kg) e.g., 1e-27 kg for proton") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                haptics.heavyTick()
                val res = PhysicsScienceSolver.solveModernPhysics(
                    freqStr.toDoubleOrNull(),
                    lambdaStr.toDoubleOrNull(),
                    massStr.toDoubleOrNull()
                )
                result = res
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_modern_physics")
        ) {
            Text("Calculate Photon Energy & De Broglie Wavelength")
        }

        result?.let { res ->
            PhysicsResultDisplayCard(res)
        }
    }
}

@Composable
fun PhysicsResultDisplayCard(res: PhysicsScienceSolver.PhysicsResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(res.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Formula: ${res.formulaUsed}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)

            HorizontalDivider()

            res.valuesMap.forEach { (key, value) ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(key, fontWeight = FontWeight.Medium, style = MaterialTheme.typography.bodyMedium)
                    Text(value, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyLarge)
                }
            }

            HorizontalDivider()

            Text("Step-by-Step Explanation:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            res.steps.forEach { step ->
                Text("• $step", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
