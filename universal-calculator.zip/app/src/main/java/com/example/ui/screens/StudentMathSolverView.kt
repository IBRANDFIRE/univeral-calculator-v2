package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CalcRepository
import com.example.engine.StudentMathSolver
import com.example.ui.components.HapticFeedbackManager
import kotlinx.coroutines.launch

@Composable
fun StudentMathSolverView(
    repository: CalcRepository,
    haptics: HapticFeedbackManager,
    modifier: Modifier = Modifier
) {
    var subTab by remember { mutableStateOf(0) }
    val subTabTitles = listOf("Find X (Equation)", "Cubic (3rd Degree)", "Linear & Quad", "3x3 System (x,y,z)", "Coord Geometry", "Perm & Comb")

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("student_math_solver_view")
    ) {
        ScrollableTabRow(
            selectedTabIndex = subTab,
            edgePadding = 4.dp,
            modifier = Modifier.fillMaxWidth().testTag("student_math_subtab_row")
        ) {
            subTabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = subTab == index,
                    onClick = {
                        haptics.tick()
                        subTab = index
                    },
                    text = { Text(title, fontSize = 12.sp) },
                    modifier = Modifier.testTag("student_subtab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (subTab) {
                0 -> GeneralFindXView(repository, haptics)
                1 -> CubicEquationView(repository, haptics)
                2 -> StepLinearQuadView(repository, haptics)
                3 -> System3x3View(repository, haptics)
                4 -> CoordinateGeometryView(repository, haptics)
                5 -> PermutationCombinationView(repository, haptics)
            }
        }
    }
}

@Composable
fun GeneralFindXView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var equationInput by remember { mutableStateOf("2x + 5 = 15") }
    var minSearch by remember { mutableStateOf("-50") }
    var maxSearch by remember { mutableStateOf("50") }
    var solveResult by remember { mutableStateOf<StudentMathSolver.GeneralEquationResult?>(null) }
    val coroutineScope = rememberCoroutineScope()

    val presets = listOf(
        "2x + 5 = 15",
        "3x - 12 = 0",
        "x^2 - 9 = 0",
        "x^2 - 5x + 6 = 0",
        "x^3 - 6x^2 + 11x - 6 = 0",
        "sin(x) = 0.5",
        "2^x = 16",
        "(x+2)/(x-1) = 4"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "🔍 Find 'X' General Equation Solver",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    "Enter any single variable equation with 'x' (e.g. 2x + 5 = 15, x² - 5x + 6 = 0, sin(x) = 0.5)",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        OutlinedTextField(
            value = equationInput,
            onValueChange = { equationInput = it },
            label = { Text("Equation f(x) = g(x)") },
            leadingIcon = { Icon(Icons.Default.Functions, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().testTag("input_find_x")
        )

        // Preset Chips
        Text("Quick Example Presets:", style = MaterialTheme.typography.labelMedium)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val chunked = presets.take(4)
            chunked.forEach { preset ->
                FilterChip(
                    selected = equationInput == preset,
                    onClick = {
                        haptics.tick()
                        equationInput = preset
                    },
                    label = { Text(preset, fontSize = 11.sp) }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = minSearch,
                onValueChange = { minSearch = it },
                label = { Text("x Min") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = maxSearch,
                onValueChange = { maxSearch = it },
                label = { Text("x Max") },
                modifier = Modifier.weight(1f)
            )
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val minVal = minSearch.toDoubleOrNull() ?: -50.0
                val maxVal = maxSearch.toDoubleOrNull() ?: 50.0
                val res = StudentMathSolver.solveEquationForX(equationInput, minVal, maxVal)
                solveResult = res

                if (res.success && res.roots.isNotEmpty()) {
                    coroutineScope.launch {
                        val rootStr = res.roots.joinToString(", ") { StudentMathSolver.formatNum(it) }
                        repository.saveCalculation(
                            category = "Student Math",
                            calculatorName = "Find X Solver",
                            expression = res.equationForm,
                            result = "x = $rootStr"
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_x")
        ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Solve for X", fontWeight = FontWeight.Bold)
        }

        solveResult?.let { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Solution Result", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                    if (res.roots.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Real Roots: ", fontWeight = FontWeight.SemiBold)
                            Text(
                                res.roots.joinToString(", ") { "x = ${StudentMathSolver.formatNum(it)}" },
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        Text(
                            res.errorMessage ?: "No real roots found",
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    HorizontalDivider()

                    Text("Step-by-Step Solving Breakdown:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    res.steps.forEach { step ->
                        Text("• $step", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun CubicEquationView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var aStr by remember { mutableStateOf("1") }
    var bStr by remember { mutableStateOf("-6") }
    var cStr by remember { mutableStateOf("11") }
    var dStr by remember { mutableStateOf("-6") }

    var cubicResult by remember { mutableStateOf<StudentMathSolver.CubicResult?>(null) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Cubic Equation Solver: ax³ + bx² + cx + d = 0", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Finds all 3 real or complex roots using Cardano's formula & reduction", style = MaterialTheme.typography.bodySmall)
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = aStr, onValueChange = { aStr = it }, label = { Text("a (x³)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = bStr, onValueChange = { bStr = it }, label = { Text("b (x²)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = cStr, onValueChange = { cStr = it }, label = { Text("c (x)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = dStr, onValueChange = { dStr = it }, label = { Text("d (const)") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                haptics.heavyTick()
                val a = aStr.toDoubleOrNull() ?: 1.0
                val b = bStr.toDoubleOrNull() ?: 0.0
                val c = cStr.toDoubleOrNull() ?: 0.0
                val d = dStr.toDoubleOrNull() ?: 0.0
                val res = StudentMathSolver.solveCubic(a, b, c, d)
                cubicResult = res

                coroutineScope.launch {
                    repository.saveCalculation(
                        category = "Student Math",
                        calculatorName = "Cubic Solver",
                        expression = "(${a})x³+(${b})x²+(${c})x+(${d})=0",
                        result = "Roots: ${res.roots.joinToString(", ")}"
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("btn_solve_cubic")
        ) {
            Text("Solve Cubic Roots")
        }

        cubicResult?.let { res ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cubic Roots:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    res.roots.forEachIndexed { idx, r ->
                        Text("Root x${idx + 1} = $r", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }

                    HorizontalDivider()
                    Text("Steps:", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    res.steps.forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun StepLinearQuadView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var isLinear by remember { mutableStateOf(false) }

    // Linear ax + b = cx + d
    var linA by remember { mutableStateOf("3") }
    var linB by remember { mutableStateOf("5") }
    var linC by remember { mutableStateOf("1") }
    var linD by remember { mutableStateOf("17") }
    var linSolution by remember { mutableStateOf<String?>(null) }

    // Quad ax^2 + bx + c = 0
    var quadA by remember { mutableStateOf("1") }
    var quadB by remember { mutableStateOf("-5") }
    var quadC by remember { mutableStateOf("6") }
    var quadSolution by remember { mutableStateOf<List<String>?>(null) }

    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !isLinear,
                onClick = { isLinear = false },
                label = { Text("Quadratic (ax² + bx + c = 0)") },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = isLinear,
                onClick = { isLinear = true },
                label = { Text("Linear (ax + b = cx + d)") },
                modifier = Modifier.weight(1f)
            )
        }

        if (isLinear) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Linear Equation: ax + b = cx + d", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = linA, onValueChange = { linA = it }, label = { Text("a") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = linB, onValueChange = { linB = it }, label = { Text("b") }, modifier = Modifier.weight(1f))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = linC, onValueChange = { linC = it }, label = { Text("c") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = linD, onValueChange = { linD = it }, label = { Text("d") }, modifier = Modifier.weight(1f))
                    }

                    Button(
                        onClick = {
                            haptics.heavyTick()
                            val a = linA.toDoubleOrNull() ?: 1.0
                            val b = linB.toDoubleOrNull() ?: 0.0
                            val c = linC.toDoubleOrNull() ?: 0.0
                            val d = linD.toDoubleOrNull() ?: 0.0

                            if (a == c) {
                                linSolution = if (b == d) "Infinite Solutions (Identity)" else "No Solution (Parallel)"
                            } else {
                                val x = (d - b) / (a - c)
                                linSolution = "x = (${d} - ${b}) / (${a} - ${c}) = ${StudentMathSolver.formatNum(x)}"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Solve Linear x")
                    }

                    linSolution?.let { sol ->
                        Text(sol, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Quadratic Equation: ax² + bx + c = 0", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = quadA, onValueChange = { quadA = it }, label = { Text("a") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = quadB, onValueChange = { quadB = it }, label = { Text("b") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = quadC, onValueChange = { quadC = it }, label = { Text("c") }, modifier = Modifier.weight(1f))
                    }

                    Button(
                        onClick = {
                            haptics.heavyTick()
                            val a = quadA.toDoubleOrNull() ?: 1.0
                            val b = quadB.toDoubleOrNull() ?: 0.0
                            val c = quadC.toDoubleOrNull() ?: 0.0

                            val disc = b * b - 4 * a * c
                            val steps = mutableListOf<String>()
                            steps.add("Discriminant Δ = b² - 4ac = ($b)² - 4($a)($c) = ${StudentMathSolver.formatNum(disc)}")

                            if (disc >= 0) {
                                val x1 = (-b + kotlin.math.sqrt(disc)) / (2 * a)
                                val x2 = (-b - kotlin.math.sqrt(disc)) / (2 * a)
                                steps.add("Real Roots x = [-b ± √Δ] / (2a)")
                                steps.add("x₁ = ${StudentMathSolver.formatNum(x1)}, x₂ = ${StudentMathSolver.formatNum(x2)}")
                            } else {
                                val real = -b / (2 * a)
                                val imag = kotlin.math.sqrt(-disc) / (2 * a)
                                steps.add("Complex Roots x = ${StudentMathSolver.formatNum(real)} ± ${StudentMathSolver.formatNum(imag)}i")
                            }

                            val vertexH = -b / (2 * a)
                            val vertexK = c - (b * b) / (4 * a)
                            steps.add("Parabola Vertex (h, k) = (${StudentMathSolver.formatNum(vertexH)}, ${StudentMathSolver.formatNum(vertexK)})")
                            steps.add("Sum of Roots (α + β) = -b/a = ${StudentMathSolver.formatNum(-b / a)}")
                            steps.add("Product of Roots (αβ) = c/a = ${StudentMathSolver.formatNum(c / a)}")

                            quadSolution = steps
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Solve Quadratic & Properties")
                    }

                    quadSolution?.forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun System3x3View(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var eq1 by remember { mutableStateOf(listOf("2", "1", "-1", "8")) }
    var eq2 by remember { mutableStateOf(listOf("-3", "-1", "2", "-11")) }
    var eq3 by remember { mutableStateOf(listOf("-2", "1", "2", "-3")) }

    var result by remember { mutableStateOf<StudentMathSolver.System3x3Result?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("3x3 Simultaneous Equations (Cramer's Rule)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Eq 1: a₁x + b₁y + c₁z = d₁", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(value = eq1[0], onValueChange = { eq1 = eq1.toMutableList().apply { set(0, it) } }, label = { Text("a1") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq1[1], onValueChange = { eq1 = eq1.toMutableList().apply { set(1, it) } }, label = { Text("b1") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq1[2], onValueChange = { eq1 = eq1.toMutableList().apply { set(2, it) } }, label = { Text("c1") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq1[3], onValueChange = { eq1 = eq1.toMutableList().apply { set(3, it) } }, label = { Text("d1") }, modifier = Modifier.weight(1f))
                }

                Text("Eq 2: a₂x + b₂y + c₂z = d₂", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(value = eq2[0], onValueChange = { eq2 = eq2.toMutableList().apply { set(0, it) } }, label = { Text("a2") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq2[1], onValueChange = { eq2 = eq2.toMutableList().apply { set(1, it) } }, label = { Text("b2") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq2[2], onValueChange = { eq2 = eq2.toMutableList().apply { set(2, it) } }, label = { Text("c2") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq2[3], onValueChange = { eq2 = eq2.toMutableList().apply { set(3, it) } }, label = { Text("d2") }, modifier = Modifier.weight(1f))
                }

                Text("Eq 3: a₃x + b₃y + c₃z = d₃", style = MaterialTheme.typography.labelSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedTextField(value = eq3[0], onValueChange = { eq3 = eq3.toMutableList().apply { set(0, it) } }, label = { Text("a3") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq3[1], onValueChange = { eq3 = eq3.toMutableList().apply { set(1, it) } }, label = { Text("b3") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq3[2], onValueChange = { eq3 = eq3.toMutableList().apply { set(2, it) } }, label = { Text("c3") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eq3[3], onValueChange = { eq3 = eq3.toMutableList().apply { set(3, it) } }, label = { Text("d3") }, modifier = Modifier.weight(1f))
                }

                Button(
                    onClick = {
                        haptics.heavyTick()
                        result = StudentMathSolver.solve3x3System(
                            eq1[0].toDoubleOrNull() ?: 1.0, eq1[1].toDoubleOrNull() ?: 0.0, eq1[2].toDoubleOrNull() ?: 0.0, eq1[3].toDoubleOrNull() ?: 0.0,
                            eq2[0].toDoubleOrNull() ?: 0.0, eq2[1].toDoubleOrNull() ?: 1.0, eq2[2].toDoubleOrNull() ?: 0.0, eq2[3].toDoubleOrNull() ?: 0.0,
                            eq3[0].toDoubleOrNull() ?: 0.0, eq3[1].toDoubleOrNull() ?: 0.0, eq3[2].toDoubleOrNull() ?: 1.0, eq3[3].toDoubleOrNull() ?: 0.0
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Solve System (x, y, z)")
                }

                result?.let { res ->
                    if (res.hasUniqueSolution) {
                        Text(
                            "x = ${StudentMathSolver.formatNum(res.x)}, y = ${StudentMathSolver.formatNum(res.y)}, z = ${StudentMathSolver.formatNum(res.z)}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    res.steps.forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun CoordinateGeometryView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var x1 by remember { mutableStateOf("1") }
    var y1 by remember { mutableStateOf("2") }
    var x2 by remember { mutableStateOf("5") }
    var y2 by remember { mutableStateOf("8") }
    var mRatio by remember { mutableStateOf("1") }
    var nRatio by remember { mutableStateOf("1") }

    var coordResult by remember { mutableStateOf<StudentMathSolver.CoordGeometryResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Coordinate Geometry (2D Points)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = x1, onValueChange = { x1 = it }, label = { Text("x1") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = y1, onValueChange = { y1 = it }, label = { Text("y1") }, modifier = Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = x2, onValueChange = { x2 = it }, label = { Text("x2") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = y2, onValueChange = { y2 = it }, label = { Text("y2") }, modifier = Modifier.weight(1f))
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = mRatio, onValueChange = { mRatio = it }, label = { Text("Section Ratio m") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = nRatio, onValueChange = { nRatio = it }, label = { Text("Section Ratio n") }, modifier = Modifier.weight(1f))
                }

                Button(
                    onClick = {
                        haptics.heavyTick()
                        coordResult = StudentMathSolver.calculateCoordinateGeometry(
                            x1.toDoubleOrNull() ?: 0.0, y1.toDoubleOrNull() ?: 0.0,
                            x2.toDoubleOrNull() ?: 1.0, y2.toDoubleOrNull() ?: 1.0,
                            mRatio.toDoubleOrNull() ?: 1.0, nRatio.toDoubleOrNull() ?: 1.0
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Calculate Distance & Line Equations")
                }

                coordResult?.steps?.forEach { step ->
                    Text(step, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@Composable
fun PermutationCombinationView(repository: CalcRepository, haptics: HapticFeedbackManager) {
    var nInput by remember { mutableStateOf("7") }
    var rInput by remember { mutableStateOf("3") }
    var permResult by remember { mutableStateOf<StudentMathSolver.PermCombResult?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Permutations & Combinations (nPr, nCr)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = nInput, onValueChange = { nInput = it }, label = { Text("Total Items (n)") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = rInput, onValueChange = { rInput = it }, label = { Text("Chosen Items (r)") }, modifier = Modifier.weight(1f))
                }

                Button(
                    onClick = {
                        haptics.heavyTick()
                        val n = nInput.toIntOrNull() ?: 1
                        val r = rInput.toIntOrNull() ?: 1
                        permResult = StudentMathSolver.calculatePermComb(n, r)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Calculate nPr & nCr")
                }

                permResult?.let { res ->
                    Text("n! = ${StudentMathSolver.formatNum(res.nFactorial)}", style = MaterialTheme.typography.titleSmall)
                    Text("nPr (Permutations) = ${StudentMathSolver.formatNum(res.nPr)}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("nCr (Combinations) = ${StudentMathSolver.formatNum(res.nCr)}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)

                    HorizontalDivider()
                    res.steps.forEach { step ->
                        Text(step, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
