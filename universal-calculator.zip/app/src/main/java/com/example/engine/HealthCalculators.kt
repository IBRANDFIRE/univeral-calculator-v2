package com.example.engine

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.log10

object HealthCalculators {

    enum class Gender { MALE, FEMALE }

    enum class ActivityLevel(val multiplier: Double, val label: String) {
        SEDENTARY(1.2, "Sedentary (desk job, little exercise)"),
        LIGHT(1.375, "Lightly Active (exercise 1-3 days/wk)"),
        MODERATE(1.55, "Moderately Active (exercise 3-5 days/wk)"),
        VERY_ACTIVE(1.725, "Very Active (exercise 6-7 days/wk)"),
        EXTRA_ACTIVE(1.9, "Extra Active (physical job & heavy exercise)")
    }

    data class BmiResult(
        val bmi: Double,
        val category: String,
        val healthyWeightRangeMin: Double,
        val healthyWeightRangeMax: Double
    )

    fun calculateBmi(weightKg: Double, heightCm: Double): BmiResult {
        if (heightCm <= 0 || weightKg <= 0) return BmiResult(0.0, "Invalid input", 0.0, 0.0)
        val heightM = heightCm / 100.0
        val bmi = weightKg / (heightM * heightM)

        val category = when {
            bmi < 18.5 -> "Underweight"
            bmi < 25.0 -> "Normal weight"
            bmi < 30.0 -> "Overweight"
            bmi < 35.0 -> "Obesity (Class 1)"
            bmi < 40.0 -> "Obesity (Class 2)"
            else -> "Severe Obesity (Class 3)"
        }

        val minWeight = 18.5 * heightM * heightM
        val maxWeight = 24.9 * heightM * heightM

        return BmiResult(bmi, category, minWeight, maxWeight)
    }

    fun calculateBmr(weightKg: Double, heightCm: Double, ageYears: Int, gender: Gender): Double {
        // Mifflin-St Jeor formula
        val base = 10.0 * weightKg + 6.25 * heightCm - 5.0 * ageYears
        return if (gender == Gender.MALE) base + 5.0 else base - 161.0
    }

    fun calculateTdee(bmr: Double, activityLevel: ActivityLevel): Double {
        return bmr * activityLevel.multiplier
    }

    data class BodyFatResult(val bodyFatPercent: Double, val category: String)

    fun calculateNavyBodyFat(
        gender: Gender,
        heightCm: Double,
        neckCm: Double,
        waistCm: Double,
        hipCm: Double = 0.0
    ): BodyFatResult? {
        if (heightCm <= 0 || neckCm <= 0 || waistCm <= 0) return null
        return try {
            val bf = if (gender == Gender.MALE) {
                if (waistCm <= neckCm) return null
                495.0 / (1.0324 - 0.19077 * log10(waistCm - neckCm) + 0.15456 * log10(heightCm)) - 450.0
            } else {
                if (waistCm + hipCm <= neckCm) return null
                495.0 / (1.29579 - 0.35004 * log10(waistCm + hipCm - neckCm) + 0.22100 * log10(heightCm)) - 450.0
            }
            val cat = when {
                bf < 10.0 -> "Essential Fat"
                bf < 20.0 -> "Athletes / Fit"
                bf < 25.0 -> "Average"
                else -> "Above Average"
            }
            BodyFatResult(bf.coerceIn(2.0, 70.0), cat)
        } catch (e: Exception) {
            null
        }
    }

    data class PregnancyResult(
        val dueDate: LocalDate,
        val gestationalWeeks: Long,
        val gestationalDays: Long,
        val trimester: String,
        val daysRemaining: Long
    )

    fun calculatePregnancy(lastMenstrualPeriod: LocalDate): PregnancyResult {
        val today = LocalDate.now()
        val dueDate = lastMenstrualPeriod.plusDays(280) // 40 weeks
        val totalDaysPregnant = ChronoUnit.DAYS.between(lastMenstrualPeriod, today).coerceAtLeast(0)
        val weeks = totalDaysPregnant / 7
        val days = totalDaysPregnant % 7
        val daysRemaining = ChronoUnit.DAYS.between(today, dueDate).coerceAtLeast(0)

        val trimester = when {
            weeks < 13 -> "1st Trimester"
            weeks < 27 -> "2nd Trimester"
            else -> "3rd Trimester"
        }

        return PregnancyResult(dueDate, weeks, days, trimester, daysRemaining)
    }

    data class MacroSplit(
        val carbsGrams: Double,
        val proteinGrams: Double,
        val fatGrams: Double,
        val carbsCalories: Double,
        val proteinCalories: Double,
        val fatCalories: Double
    )

    fun calculateMacros(
        targetCalories: Double,
        carbPct: Double,
        proteinPct: Double,
        fatPct: Double
    ): MacroSplit {
        val carbCal = targetCalories * (carbPct / 100.0)
        val protCal = targetCalories * (proteinPct / 100.0)
        val fatCal = targetCalories * (fatPct / 100.0)

        val carbG = carbCal / 4.0
        val protG = protCal / 4.0
        val fatG = fatCal / 9.0

        return MacroSplit(carbG, protG, fatG, carbCal, protCal, fatCal)
    }
}
