package com.example.engine

import kotlin.math.*

object StudentMathSolver {

    // 1. General Equation Solver "Find X" for f(x) = g(x) or f(x) = 0
    data class GeneralEquationResult(
        val success: Boolean,
        val equationForm: String,
        val roots: List<Double>,
        val steps: List<String>,
        val errorMessage: String? = null
    )

    fun solveEquationForX(rawInput: String, searchMin: Double = -50.0, searchMax: Double = 50.0): GeneralEquationResult {
        if (rawInput.isBlank()) return GeneralEquationResult(false, "", emptyList(), emptyList(), "Equation cannot be empty")

        val parts = if (rawInput.contains("=")) rawInput.split("=") else listOf(rawInput, "0")
        if (parts.size != 2) return GeneralEquationResult(false, rawInput, emptyList(), emptyList(), "Equation should have one '=' sign")

        val lhsStr = parts[0].trim()
        val rhsStr = parts[1].trim()
        val combinedExpr = "($lhsStr) - ($rhsStr)"

        val steps = mutableListOf<String>()
        steps.add("Step 1: Standard form F(x) = LHS - RHS = 0")
        steps.add("F(x) = ($lhsStr) - ($rhsStr) = 0")

        // Numerical scan across [searchMin, searchMax]
        val roots = mutableListOf<Double>()
        val samples = 350
        val stepSize = (searchMax - searchMin) / samples
        var xPrev = searchMin
        var yPrev = ScientificCalculators.evaluateFunction(combinedExpr, xPrev)

        for (i in 1..samples) {
            val xCurr = searchMin + i * stepSize
            val yCurr = ScientificCalculators.evaluateFunction(combinedExpr, xCurr)

            if (!yPrev.isNaN() && !yCurr.isNaN()) {
                if (yPrev * yCurr <= 0.0) {
                    // Refine root via Bisection
                    var a = xPrev
                    var b = xCurr
                    var rootFound = Double.NaN
                    for (k in 0..25) {
                        val mid = (a + b) / 2.0
                        val yMid = ScientificCalculators.evaluateFunction(combinedExpr, mid)
                        if (abs(yMid) < 1e-8) {
                            rootFound = mid
                            break
                        }
                        if (ScientificCalculators.evaluateFunction(combinedExpr, a) * yMid <= 0.0) {
                            b = mid
                        } else {
                            a = mid
                        }
                        rootFound = (a + b) / 2.0
                    }

                    if (!rootFound.isNaN() && roots.none { abs(it - rootFound) < 1e-4 }) {
                        roots.add(rootFound)
                    }
                }
            }
            xPrev = xCurr
            yPrev = yCurr
        }

        if (roots.isEmpty()) {
            steps.add("Step 2: Scanned x from $searchMin to $searchMax. No real roots found in this interval.")
            return GeneralEquationResult(true, "$lhsStr = $rhsStr", emptyList(), steps, "No real solutions found in range [$searchMin, $searchMax]")
        } else {
            steps.add("Step 2: Found ${roots.size} real solution(s) for x:")
            roots.forEachIndexed { idx, r ->
                val lhsVal = ScientificCalculators.evaluateFunction(lhsStr, r)
                val rhsVal = ScientificCalculators.evaluateFunction(rhsStr, r)
                val roundedR = formatNum(r)
                steps.add("  • Root x${idx + 1} ≈ $roundedR  (Verification: LHS ≈ ${formatNum(lhsVal)}, RHS ≈ ${formatNum(rhsVal)})")
            }
            return GeneralEquationResult(true, "$lhsStr = $rhsStr", roots, steps)
        }
    }

    // 2. Cubic Equation Solver: ax^3 + bx^2 + cx + d = 0
    data class CubicResult(
        val roots: List<String>,
        val realRootsCount: Int,
        val discriminant: Double,
        val steps: List<String>
    )

    fun solveCubic(a: Double, b: Double, c: Double, d: Double): CubicResult {
        val steps = mutableListOf<String>()
        steps.add("Equation: (${a})x³ + (${b})x² + (${c})x + (${d}) = 0")

        if (abs(a) < 1e-12) {
            steps.add("a = 0, degrading to quadratic equation.")
            val quadRes = ScientificCalculators.solveQuadratic(b, c, d)
            val rootsList = mutableListOf<String>()
            when (quadRes) {
                is ScientificCalculators.QuadraticResult.RealRoots -> {
                    rootsList.add(formatNum(quadRes.x1))
                    rootsList.add(formatNum(quadRes.x2))
                }
                is ScientificCalculators.QuadraticResult.ComplexRoots -> {
                    rootsList.add("${formatNum(quadRes.realPart)} + ${formatNum(quadRes.imaginaryPart)}i")
                    rootsList.add("${formatNum(quadRes.realPart)} - ${formatNum(quadRes.imaginaryPart)}i")
                }
                else -> rootsList.add("No valid equation")
            }
            return CubicResult(rootsList, rootsList.size, 0.0, steps)
        }

        // Convert to depressed cubic t^3 + pt + q = 0 by x = t - b/(3a)
        val p = (3.0 * a * c - b * b) / (3.0 * a * a)
        val q = (2.0 * b * b * b - 9.0 * a * b * c + 27.0 * a * a * d) / (27.0 * a * a * a)
        val disc = (q * q / 4.0) + (p * p * p / 27.0)

        steps.add("Step 1: Reduce to depressed cubic t³ + pt + q = 0 via substitution x = t - b/(3a)")
        steps.add("  p = ${formatNum(p)}, q = ${formatNum(q)}")
        steps.add("  Discriminant Δ = q²/4 + p³/27 = ${formatNum(disc)}")

        val roots = mutableListOf<String>()
        var realCount = 0
        val shift = -b / (3.0 * a)

        if (disc > 1e-12) {
            realCount = 1
            val u = cbrt(-q / 2.0 + sqrt(disc))
            val v = cbrt(-q / 2.0 - sqrt(disc))
            val t1 = u + v
            val x1 = t1 + shift
            val realPart = -(u + v) / 2.0 + shift
            val imagPart = (sqrt(3.0) / 2.0) * abs(u - v)

            roots.add(formatNum(x1))
            roots.add("${formatNum(realPart)} + ${formatNum(imagPart)}i")
            roots.add("${formatNum(realPart)} - ${formatNum(imagPart)}i")

            steps.add("Step 2: Δ > 0 ⇒ 1 Real Root & 2 Complex Conjugate Roots")
            steps.add("  x₁ = ${formatNum(x1)}")
            steps.add("  x₂,₃ = ${formatNum(realPart)} ± ${formatNum(imagPart)}i")
        } else if (abs(disc) <= 1e-12) {
            realCount = 3
            val u = cbrt(-q / 2.0)
            val t1 = 2.0 * u
            val t2 = -u
            val x1 = t1 + shift
            val x2 = t2 + shift

            roots.add(formatNum(x1))
            roots.add(formatNum(x2))
            roots.add(formatNum(x2))

            steps.add("Step 2: Δ = 0 ⇒ 3 Real Roots (Multiple roots)")
            steps.add("  x₁ = ${formatNum(x1)}")
            steps.add("  x₂ = x₃ = ${formatNum(x2)}")
        } else {
            realCount = 3
            val r = sqrt(-p * p * p / 27.0)
            val phi = acos((-q / 2.0) / r)
            val t1 = 2.0 * cbrt(r) * cos(phi / 3.0)
            val t2 = 2.0 * cbrt(r) * cos((phi + 2.0 * PI) / 3.0)
            val t3 = 2.0 * cbrt(r) * cos((phi + 4.0 * PI) / 3.0)

            val x1 = t1 + shift
            val x2 = t2 + shift
            val x3 = t3 + shift

            roots.add(formatNum(x1))
            roots.add(formatNum(x2))
            roots.add(formatNum(x3))

            steps.add("Step 2: Δ < 0 ⇒ 3 Distinct Real Roots")
            steps.add("  x₁ = ${formatNum(x1)}")
            steps.add("  x₂ = ${formatNum(x2)}")
            steps.add("  x₃ = ${formatNum(x3)}")
        }

        return CubicResult(roots, realCount, disc, steps)
    }

    // 3. AP (Arithmetic Progression) Calculator
    data class APResult(
        val nthTerm: Double,
        val sumN: Double,
        val sequencePreview: List<Double>,
        val steps: List<String>
    )

    fun calculateAP(a: Double, d: Double, n: Int): APResult {
        val steps = mutableListOf<String>()
        val an = a + (n - 1) * d
        val sn = (n / 2.0) * (2 * a + (n - 1) * d)

        steps.add("AP Parameters: First term (a) = $a, Common Difference (d) = $d, Terms (n) = $n")
        steps.add("1. n-th term formula: aₙ = a + (n - 1)d")
        steps.add("   a_$n = $a + ($n - 1) × $d = ${formatNum(an)}")
        steps.add("2. Sum formula: Sₙ = (n/2) × [2a + (n - 1)d]")
        steps.add("   S_$n = ($n/2) × [2($a) + ($n - 1)($d)] = ${formatNum(sn)}")

        val preview = mutableListOf<Double>()
        val count = minOf(n, 10)
        for (i in 0 until count) {
            preview.add(a + i * d)
        }

        return APResult(an, sn, preview, steps)
    }

    // 4. GP (Geometric Progression) Calculator
    data class GPResult(
        val nthTerm: Double,
        val sumN: Double,
        val infiniteSum: Double?,
        val sequencePreview: List<Double>,
        val steps: List<String>
    )

    fun calculateGP(a: Double, r: Double, n: Int): GPResult {
        val steps = mutableListOf<String>()
        val an = a * r.pow((n - 1).toDouble())

        val sn = if (abs(r - 1.0) < 1e-12) {
            a * n
        } else {
            a * (r.pow(n.toDouble()) - 1.0) / (r - 1.0)
        }

        val sInf = if (abs(r) < 1.0) {
            a / (1.0 - r)
        } else null

        steps.add("GP Parameters: First term (a) = $a, Common Ratio (r) = $r, Terms (n) = $n")
        steps.add("1. n-th term formula: aₙ = a × rⁿ⁻¹")
        steps.add("   a_$n = $a × $r^${n-1} = ${formatNum(an)}")
        steps.add("2. Sum formula: Sₙ = a(rⁿ - 1) / (r - 1)")
        steps.add("   S_$n = $a × ($r^$n - 1) / ($r - 1) = ${formatNum(sn)}")

        if (sInf != null) {
            steps.add("3. Infinite GP Sum (|r| < 1): S_∞ = a / (1 - r) = $a / (1 - $r) = ${formatNum(sInf)}")
        } else {
            steps.add("3. Infinite GP Sum: Divergent (|r| ≥ 1)")
        }

        val preview = mutableListOf<Double>()
        val count = minOf(n, 10)
        var curr = a
        for (i in 0 until count) {
            preview.add(curr)
            curr *= r
        }

        return GPResult(an, sn, sInf, preview, steps)
    }

    // 5. Series Summation Calculator: Σ_{k=start}^{end} f(k)
    data class SeriesSumResult(
        val sumValue: Double,
        val terms: List<Double>,
        val formulaName: String?,
        val steps: List<String>
    )

    fun calculateSeriesSum(expr: String, kStart: Int, kEnd: Int): SeriesSumResult {
        val steps = mutableListOf<String>()
        steps.add("Summation: Σ_{k=$kStart}^{$kEnd} ($expr)")

        var sum = 0.0
        val terms = mutableListOf<Double>()
        val maxTermsPreview = 15

        for (k in kStart..kEnd) {
            val evalExpr = expr.replace(Regex("(?i)\\bk\\b"), "($k)")
            val res = HighPrecisionEvaluator.evaluate(evalExpr, HighPrecisionEvaluator.AngleUnit.RADIANS)
            val valK = if (res.success) res.value else Double.NaN
            if (!valK.isNaN()) {
                sum += valK
                if (terms.size < maxTermsPreview) {
                    terms.add(valK)
                }
            }
        }

        val exprClean = expr.trim().lowercase()
        var formulaName: String? = null

        if (kStart == 1) {
            val n = kEnd.toDouble()
            when (exprClean) {
                "k" -> {
                    formulaName = "Sum of first n natural numbers: n(n + 1) / 2"
                    val formulaVal = n * (n + 1) / 2.0
                    steps.add("Standard Formula applied: S = $n × ($n + 1) / 2 = $formulaVal")
                }
                "k^2", "k*k" -> {
                    formulaName = "Sum of squares: n(n + 1)(2n + 1) / 6"
                    val formulaVal = n * (n + 1) * (2 * n + 1) / 6.0
                    steps.add("Standard Formula applied: S = $n × ($n + 1) × (2×$n + 1) / 6 = $formulaVal")
                }
                "k^3", "k*k*k" -> {
                    formulaName = "Sum of cubes: [n(n + 1) / 2]²"
                    val formulaVal = (n * (n + 1) / 2.0).pow(2.0)
                    steps.add("Standard Formula applied: S = [$n × ($n + 1) / 2]² = $formulaVal")
                }
            }
        }

        steps.add("Evaluated sum from k = $kStart to $kEnd = ${formatNum(sum)}")
        return SeriesSumResult(sum, terms, formulaName, steps)
    }

    // 6. 3x3 System Solver (Cramer's Rule)
    data class System3x3Result(
        val x: Double,
        val y: Double,
        val z: Double,
        val detD: Double,
        val hasUniqueSolution: Boolean,
        val steps: List<String>
    )

    fun solve3x3System(
        a1: Double, b1: Double, c1: Double, d1: Double,
        a2: Double, b2: Double, c2: Double, d2: Double,
        a3: Double, b3: Double, c3: Double, d3: Double
    ): System3x3Result {
        val steps = mutableListOf<String>()
        steps.add("System of 3 Equations:")
        steps.add("  1) (${a1})x + (${b1})y + (${c1})z = $d1")
        steps.add("  2) (${a2})x + (${b2})y + (${c2})z = $d2")
        steps.add("  3) (${a3})x + (${b3})y + (${c3})z = $d3")

        fun det3(
            m11: Double, m12: Double, m13: Double,
            m21: Double, m22: Double, m23: Double,
            m31: Double, m32: Double, m33: Double
        ): Double {
            return m11 * (m22 * m33 - m23 * m32) -
                   m12 * (m21 * m33 - m23 * m31) +
                   m13 * (m21 * m32 - m22 * m31)
        }

        val detD = det3(a1, b1, c1, a2, b2, c2, a3, b3, c3)
        steps.add("Step 1: Calculate Main Determinant Δ = ${formatNum(detD)}")

        if (abs(detD) < 1e-12) {
            steps.add("Δ = 0 ⇒ System does not have a unique solution (Inconsistent or Dependent).")
            return System3x3Result(0.0, 0.0, 0.0, detD, false, steps)
        }

        val detDx = det3(d1, b1, c1, d2, b2, c2, d3, b3, c3)
        val detDy = det3(a1, d1, c1, a2, d2, c2, a3, d3, c3)
        val detDz = det3(a1, b1, d1, a2, b2, d2, a3, b3, d3)

        val x = detDx / detD
        val y = detDy / detD
        val z = detDz / detD

        steps.add("Step 2: Cramer's Rule Determinants:")
        steps.add("  Δx = ${formatNum(detDx)}, Δy = ${formatNum(detDy)}, Δz = ${formatNum(detDz)}")
        steps.add("Step 3: Solution x = Δx/Δ, y = Δy/Δ, z = Δz/Δ")
        steps.add("  x = ${formatNum(x)}, y = ${formatNum(y)}, z = ${formatNum(z)}")

        return System3x3Result(x, y, z, detD, true, steps)
    }

    // 7. Coordinate Geometry Solvers (Distance, Midpoint, Section Formula, Line Slope)
    data class CoordGeometryResult(
        val distance: Double,
        val midpoint: Pair<Double, Double>,
        val sectionPoint: Pair<Double, Double>?,
        val slope: Double?,
        val lineEquation: String,
        val steps: List<String>
    )

    fun calculateCoordinateGeometry(
        x1: Double, y1: Double,
        x2: Double, y2: Double,
        ratioM: Double = 1.0, ratioN: Double = 1.0
    ): CoordGeometryResult {
        val steps = mutableListOf<String>()
        steps.add("Points: A($x1, $y1), B($x2, $y2)")

        val dx = x2 - x1
        val dy = y2 - y1
        val dist = sqrt(dx * dx + dy * dy)
        steps.add("1. Distance: d = √[(x₂ - x₁)² + (y₂ - y₁)²] = ${formatNum(dist)}")

        val mx = (x1 + x2) / 2.0
        val my = (y1 + y2) / 2.0
        steps.add("2. Midpoint: M = ((x₁ + x₂)/2, (y₁ + y₂)/2) = (${formatNum(mx)}, ${formatNum(my)})")

        val secPoint = if (ratioM + ratioN != 0.0) {
            val px = (ratioM * x2 + ratioN * x1) / (ratioM + ratioN)
            val py = (ratioM * y2 + ratioN * y1) / (ratioM + ratioN)
            steps.add("3. Section Point ($ratioM : $ratioN ratio): P = (${formatNum(px)}, ${formatNum(py)})")
            Pair(px, py)
        } else null

        val slope = if (abs(dx) > 1e-12) {
            val m = dy / dx
            steps.add("4. Slope (m): (y₂ - y₁)/(x₂ - x₁) = ${formatNum(m)}")
            m
        } else {
            steps.add("4. Slope (m): Vertical Line (Undefined slope)")
            null
        }

        val lineEq = if (slope != null) {
            val c = y1 - slope * x1
            "y = ${formatNum(slope)}x + ${formatNum(c)}"
        } else {
            "x = $x1"
        }
        steps.add("5. Line Equation: $lineEq")

        return CoordGeometryResult(dist, Pair(mx, my), secPoint, slope, lineEq, steps)
    }

    // Permutations & Combinations
    data class PermCombResult(
        val nFactorial: Double,
        val nPr: Double,
        val nCr: Double,
        val steps: List<String>
    )

    fun calculatePermComb(n: Int, r: Int): PermCombResult {
        val steps = mutableListOf<String>()
        fun fact(k: Int): Double {
            var res = 1.0
            for (i in 2..k) res *= i
            return res
        }

        val nf = fact(n)
        val npr = if (r in 0..n) fact(n) / fact(n - r) else 0.0
        val ncr = if (r in 0..n) fact(n) / (fact(r) * fact(n - r)) else 0.0

        steps.add("Inputs: n = $n, r = $r")
        steps.add("1. n! = $n! = ${formatNum(nf)}")
        steps.add("2. Permutations nPr = n! / (n - r)! = $n! / ${n - r}! = ${formatNum(npr)}")
        steps.add("3. Combinations nCr = n! / [r!(n - r)!] = $n! / [$r! × ${n - r}!] = ${formatNum(ncr)}")

        return PermCombResult(nf, npr, ncr, steps)
    }

    // Helper utilities
    private fun cbrt(x: Double): Double = if (x < 0) -(-x).pow(1.0 / 3.0) else x.pow(1.0 / 3.0)

    private fun roundToPrecision(value: Double, precision: Int): Double {
        if (value.isNaN() || value.isInfinite()) return value
        val scale = 10.0.pow(precision.toDouble())
        return (value * scale).roundToLong() / scale
    }

    fun formatNum(value: Double): String {
        if (value.isNaN()) return "NaN"
        if (value.isInfinite()) return if (value > 0) "∞" else "-∞"
        val rounded = roundToPrecision(value, 4)
        return if (rounded == rounded.toLong().toDouble()) {
            rounded.toLong().toString()
        } else {
            rounded.toString()
        }
    }
}
