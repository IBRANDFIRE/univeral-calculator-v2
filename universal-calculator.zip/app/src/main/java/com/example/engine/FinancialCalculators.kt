package com.example.engine

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.pow

object FinancialCalculators {

    data class AmortizationRow(
        val month: Int,
        val year: Int,
        val payment: Double,
        val principalPaid: Double,
        val interestPaid: Double,
        val remainingBalance: Double
    )

    data class LoanEmiResult(
        val monthlyEmi: Double,
        val totalInterest: Double,
        val totalPayment: Double,
        val amortizationSchedule: List<AmortizationRow>
    )

    fun calculateLoanEmi(
        principal: Double,
        annualRatePercent: Double,
        tenureYears: Double
    ): LoanEmiResult {
        if (principal <= 0 || tenureYears <= 0) {
            return LoanEmiResult(0.0, 0.0, 0.0, emptyList())
        }

        val totalMonths = (tenureYears * 12).toInt()
        val monthlyRate = (annualRatePercent / 100.0) / 12.0

        val monthlyEmi = if (monthlyRate > 0) {
            val factor = (1.0 + monthlyRate).pow(totalMonths.toDouble())
            principal * monthlyRate * factor / (factor - 1.0)
        } else {
            principal / totalMonths
        }

        val totalPayment = monthlyEmi * totalMonths
        val totalInterest = totalPayment - principal

        val schedule = mutableListOf<AmortizationRow>()
        var balance = principal

        for (m in 1..totalMonths) {
            val interestPart = if (monthlyRate > 0) balance * monthlyRate else 0.0
            val principalPart = monthlyEmi - interestPart
            balance = (balance - principalPart).coerceAtLeast(0.0)

            schedule.add(
                AmortizationRow(
                    month = m,
                    year = (m - 1) / 12 + 1,
                    payment = monthlyEmi,
                    principalPaid = principalPart,
                    interestPaid = interestPart,
                    remainingBalance = balance
                )
            )
        }

        return LoanEmiResult(monthlyEmi, totalInterest, totalPayment, schedule)
    }

    data class SipResult(
        val totalInvested: Double,
        val wealthGained: Double,
        val totalMaturity: Double,
        val yearlyBreakdown: List<Pair<Int, Double>> // Year to Balance
    )

    fun calculateSip(
        monthlyDeposit: Double,
        expectedAnnualReturnPercent: Double,
        tenureYears: Int
    ): SipResult {
        if (monthlyDeposit <= 0 || tenureYears <= 0) {
            return SipResult(0.0, 0.0, 0.0, emptyList())
        }

        val totalMonths = tenureYears * 12
        val i = (expectedAnnualReturnPercent / 100.0) / 12.0
        val totalInvested = monthlyDeposit * totalMonths

        var maturity = 0.0
        val yearly = mutableListOf<Pair<Int, Double>>()

        if (i > 0) {
            val futureValue = monthlyDeposit * ((1.0 + i).pow(totalMonths.toDouble()) - 1.0) * (1.0 + i) / i
            maturity = futureValue
            for (y in 1..tenureYears) {
                val m = y * 12
                val curVal = monthlyDeposit * ((1.0 + i).pow(m.toDouble()) - 1.0) * (1.0 + i) / i
                yearly.add(y to curVal)
            }
        } else {
            maturity = totalInvested
            for (y in 1..tenureYears) {
                yearly.add(y to monthlyDeposit * y * 12)
            }
        }

        val wealthGained = maturity - totalInvested
        return SipResult(totalInvested, wealthGained, maturity, yearly)
    }

    data class Currency(val code: String, val name: String, val symbol: String, val rateToUsd: Double)

    val DEFAULT_CURRENCIES = listOf(
        Currency("USD", "US Dollar", "$", 1.0),
        Currency("EUR", "Euro", "€", 0.92),
        Currency("GBP", "British Pound", "£", 0.79),
        Currency("JPY", "Japanese Yen", "¥", 154.20),
        Currency("CAD", "Canadian Dollar", "CA$", 1.37),
        Currency("AUD", "Australian Dollar", "A$", 1.52),
        Currency("INR", "Indian Rupee", "₹", 83.45),
        Currency("CHF", "Swiss Franc", "CHF", 0.91),
        Currency("CNY", "Chinese Yuan", "¥", 7.24),
        Currency("SGD", "Singapore Dollar", "S$", 1.35),
        Currency("BRL", "Brazilian Real", "R$", 5.15),
        Currency("MXN", "Mexican Peso", "Mex$", 16.85),
        Currency("AED", "UAE Dirham", "AED", 3.67)
    )

    fun convertCurrency(amount: Double, fromCode: String, toCode: String): Double {
        val from = DEFAULT_CURRENCIES.find { it.code == fromCode }?.rateToUsd ?: 1.0
        val to = DEFAULT_CURRENCIES.find { it.code == toCode }?.rateToUsd ?: 1.0
        // Amount in USD = amount / from; Amount in To = USD * to
        val inUsd = amount / from
        return inUsd * to
    }

    data class TipResult(
        val tipAmount: Double,
        val totalAmount: Double,
        val perPersonTip: Double,
        val perPersonTotal: Double
    )

    fun calculateTip(billAmount: Double, tipPercent: Double, splitCount: Int): TipResult {
        val people = splitCount.coerceAtLeast(1)
        val tip = billAmount * (tipPercent / 100.0)
        val total = billAmount + tip
        return TipResult(
            tipAmount = tip,
            totalAmount = total,
            perPersonTip = tip / people,
            perPersonTotal = total / people
        )
    }

    data class TaxResult(
        val netAmount: Double,
        val taxAmount: Double,
        val grossAmount: Double
    )

    fun calculateTax(amount: Double, ratePercent: Double, isTaxInclusive: Boolean): TaxResult {
        return if (isTaxInclusive) {
            // Amount is gross
            val net = amount / (1.0 + ratePercent / 100.0)
            val tax = amount - net
            TaxResult(net, tax, amount)
        } else {
            // Amount is net
            val tax = amount * (ratePercent / 100.0)
            val gross = amount + tax
            TaxResult(amount, tax, gross)
        }
    }

    data class MarginResult(
        val profit: Double,
        val marginPercent: Double,
        val markupPercent: Double
    )

    fun calculateMargin(cost: Double, revenue: Double): MarginResult {
        val profit = revenue - cost
        val margin = if (revenue > 0) (profit / revenue) * 100.0 else 0.0
        val markup = if (cost > 0) (profit / cost) * 100.0 else 0.0
        return MarginResult(profit, margin, markup)
    }

    data class BreakEvenResult(
        val breakEvenUnits: Double,
        val breakEvenRevenue: Double
    )

    fun calculateBreakEven(fixedCosts: Double, pricePerUnit: Double, variableCostPerUnit: Double): BreakEvenResult {
        val contributionMargin = pricePerUnit - variableCostPerUnit
        if (contributionMargin <= 0) return BreakEvenResult(0.0, 0.0)
        val units = fixedCosts / contributionMargin
        val revenue = units * pricePerUnit
        return BreakEvenResult(units, revenue)
    }

    data class RetirementResult(
        val targetCorpus: Double,
        val requiredMonthlySavings: Double,
        val projectedSavingsAtRetirement: Double
    )

    fun calculateRetirement(
        currentAge: Int,
        retirementAge: Int,
        currentSavings: Double,
        monthlyContribution: Double,
        expectedReturnRate: Double,
        desiredMonthlyPension: Double
    ): RetirementResult {
        val yearsToRetire = (retirementAge - currentAge).coerceAtLeast(1)
        val months = yearsToRetire * 12
        val r = (expectedReturnRate / 100.0) / 12.0

        // Future value of current savings
        val fvCurrent = currentSavings * (1.0 + r).pow(months.toDouble())
        // Future value of contributions
        val fvMonthly = if (r > 0) {
            monthlyContribution * ((1.0 + r).pow(months.toDouble()) - 1.0) / r
        } else {
            monthlyContribution * months
        }
        val projected = fvCurrent + fvMonthly

        // 4% safe withdrawal rate rule for desired monthly pension:
        val targetCorpus = (desiredMonthlyPension * 12.0) / 0.04

        val deficit = (targetCorpus - fvCurrent).coerceAtLeast(0.0)
        val requiredMonthly = if (r > 0 && deficit > 0) {
            deficit * r / ((1.0 + r).pow(months.toDouble()) - 1.0)
        } else {
            deficit / months
        }

        return RetirementResult(targetCorpus, requiredMonthly, projected)
    }
}
