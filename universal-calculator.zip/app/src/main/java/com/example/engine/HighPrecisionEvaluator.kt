package com.example.engine

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.util.Stack
import kotlin.math.*

object HighPrecisionEvaluator {

    enum class AngleUnit { DEGREES, RADIANS }

    data class EvalResult(
        val success: Boolean,
        val value: Double = 0.0,
        val formatted: String = "",
        val error: String? = null
    )

    fun evaluate(expression: String, angleUnit: AngleUnit = AngleUnit.DEGREES): EvalResult {
        if (expression.isBlank()) return EvalResult(false, error = "Empty expression")

        return try {
            val sanitized = sanitize(expression)
            val tokens = tokenize(sanitized)
            val tokensWithMul = insertImplicitMultiplication(tokens)
            val postfix = infixToPostfix(tokensWithMul)
            val result = evaluatePostfix(postfix, angleUnit)

            val formatted = formatResult(result)
            EvalResult(true, value = result, formatted = formatted)
        } catch (e: ArithmeticException) {
            EvalResult(false, error = e.message ?: "Math error")
        } catch (e: Exception) {
            EvalResult(false, error = "Invalid expression")
        }
    }

    private fun sanitize(expr: String): String {
        return expr.replace("×", "*")
            .replace("÷", "/")
            .replace("π", "PI")
            .replace("√", "sqrt")
            .replace(" ", "")
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        val len = expr.length

        while (i < len) {
            val c = expr[i]
            when {
                c.isDigit() || c == '.' -> {
                    val sb = StringBuilder()
                    while (i < len && (expr[i].isDigit() || expr[i] == '.')) {
                        sb.append(expr[i])
                        i++
                    }
                    // Handle scientific notation e.g. 1.23e-4 or 5e2
                    if (i < len && (expr[i] == 'e' || expr[i] == 'E') && i + 1 < len &&
                        (expr[i + 1].isDigit() || ((expr[i + 1] == '+' || expr[i + 1] == '-') && i + 2 < len && expr[i + 2].isDigit()))
                    ) {
                        sb.append(expr[i])
                        i++
                        if (i < len && (expr[i] == '+' || expr[i] == '-')) {
                            sb.append(expr[i])
                            i++
                        }
                        while (i < len && expr[i].isDigit()) {
                            sb.append(expr[i])
                            i++
                        }
                    }
                    tokens.add(sb.toString())
                }
                c.isLetter() -> {
                    val sb = StringBuilder()
                    while (i < len && expr[i].isLetter()) {
                        sb.append(expr[i])
                        i++
                    }
                    val word = sb.toString().lowercase()
                    if (word == "pi") {
                        tokens.add("PI")
                    } else if (word == "e") {
                        tokens.add("E")
                    } else {
                        tokens.add(word)
                    }
                }
                c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '%' || c == '!' -> {
                    // Check for unary minus:
                    if (c == '-' && (tokens.isEmpty() || tokens.last() == "(" || (isOperator(tokens.last()) && tokens.last() != "!" && tokens.last() != "%"))) {
                        tokens.add("u-")
                    } else {
                        tokens.add(c.toString())
                    }
                    i++
                }
                c == '(' || c == ')' -> {
                    tokens.add(c.toString())
                    i++
                }
                else -> i++
            }
        }
        return tokens
    }

    private fun insertImplicitMultiplication(rawTokens: List<String>): List<String> {
        if (rawTokens.size <= 1) return rawTokens
        val result = mutableListOf<String>()

        fun canBeLeftOfImplicitMul(t: String): Boolean {
            return t.toDoubleOrNull() != null || t == "PI" || t == "E" || t == ")" || t == "!" || t == "%"
        }

        fun canBeRightOfImplicitMul(t: String): Boolean {
            return t.toDoubleOrNull() != null || t == "PI" || t == "E" || t == "(" || isFunction(t)
        }

        for (i in rawTokens.indices) {
            result.add(rawTokens[i])
            if (i < rawTokens.size - 1) {
                val curr = rawTokens[i]
                val next = rawTokens[i + 1]
                if (canBeLeftOfImplicitMul(curr) && canBeRightOfImplicitMul(next)) {
                    result.add("*")
                }
            }
        }
        return result
    }

    private fun isOperator(s: String): Boolean {
        return s in listOf("+", "-", "*", "/", "^", "%", "u-", "!")
    }

    private fun precedence(op: String): Int {
        return when (op) {
            "+", "-" -> 1
            "*", "/" -> 2
            "u-" -> 3
            "^" -> 4
            "!", "%" -> 5
            else -> 0
        }
    }

    private fun isFunction(token: String): Boolean {
        return token in listOf("sin", "cos", "tan", "asin", "acos", "atan", "sinh", "cosh", "tanh", "ln", "log", "sqrt", "cbrt", "abs", "exp", "floor", "ceil", "round")
    }

    private fun infixToPostfix(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val stack = Stack<String>()

        for (token in tokens) {
            when {
                token.toDoubleOrNull() != null || token == "PI" || token == "E" -> {
                    output.add(token)
                }
                isFunction(token) -> {
                    stack.push(token)
                }
                token == "(" -> {
                    stack.push(token)
                }
                token == ")" -> {
                    while (stack.isNotEmpty() && stack.peek() != "(") {
                        output.add(stack.pop())
                    }
                    if (stack.isNotEmpty() && stack.peek() == "(") {
                        stack.pop()
                    }
                    if (stack.isNotEmpty() && isFunction(stack.peek())) {
                        output.add(stack.pop())
                    }
                }
                token == "!" || token == "%" -> {
                    output.add(token) // Postfix unary
                }
                isOperator(token) -> {
                    while (stack.isNotEmpty() && stack.peek() != "(" &&
                        (precedence(stack.peek()) > precedence(token) ||
                            (precedence(stack.peek()) == precedence(token) && token != "^" && token != "u-"))
                    ) {
                        output.add(stack.pop())
                    }
                    stack.push(token)
                }
            }
        }
        while (stack.isNotEmpty()) {
            val top = stack.pop()
            if (top != "(") output.add(top)
        }
        return output
    }

    private fun evaluatePostfix(postfix: List<String>, angleUnit: AngleUnit): Double {
        val stack = Stack<Double>()

        for (token in postfix) {
            when {
                token == "PI" -> stack.push(Math.PI)
                token == "E" -> stack.push(Math.E)
                token.toDoubleOrNull() != null -> stack.push(token.toDouble())
                token == "u-" -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Malformed syntax")
                    stack.push(-stack.pop())
                }
                token == "!" -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Malformed syntax")
                    val v = stack.pop()
                    if (v < 0 || v != floor(v)) throw ArithmeticException("Factorial only for non-negative integers")
                    stack.push(factorial(v.toInt()))
                }
                token == "%" -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Malformed syntax")
                    stack.push(stack.pop() / 100.0)
                }
                isFunction(token) -> {
                    if (stack.isEmpty()) throw IllegalArgumentException("Missing argument for $token")
                    val arg = stack.pop()
                    val rad = if (angleUnit == AngleUnit.DEGREES) Math.toRadians(arg) else arg
                    val res = when (token) {
                        "sin" -> {
                            val s = sin(rad)
                            if (abs(s) < 1e-15) 0.0 else if (abs(s - round(s)) < 1e-15) round(s) else s
                        }
                        "cos" -> {
                            val c = cos(rad)
                            if (abs(c) < 1e-15) 0.0 else if (abs(c - round(c)) < 1e-15) round(c) else c
                        }
                        "tan" -> {
                            if (abs(cos(rad)) < 1e-12) throw ArithmeticException("Tangent undefined")
                            val t = tan(rad)
                            if (abs(t) < 1e-15) 0.0 else if (abs(t - round(t)) < 1e-15) round(t) else t
                        }
                        "asin" -> {
                            if (arg < -1.0 || arg > 1.0) throw ArithmeticException("Domain error for asin")
                            val r = asin(arg)
                            if (angleUnit == AngleUnit.DEGREES) Math.toDegrees(r) else r
                        }
                        "acos" -> {
                            if (arg < -1.0 || arg > 1.0) throw ArithmeticException("Domain error for acos")
                            val r = acos(arg)
                            if (angleUnit == AngleUnit.DEGREES) Math.toDegrees(r) else r
                        }
                        "atan" -> {
                            val r = atan(arg)
                            if (angleUnit == AngleUnit.DEGREES) Math.toDegrees(r) else r
                        }
                        "sinh" -> sinh(arg)
                        "cosh" -> cosh(arg)
                        "tanh" -> tanh(arg)
                        "ln" -> {
                            if (arg <= 0) throw ArithmeticException("Domain error for ln")
                            ln(arg)
                        }
                        "log" -> {
                            if (arg <= 0) throw ArithmeticException("Domain error for log10")
                            log10(arg)
                        }
                        "sqrt" -> {
                            if (arg < 0) throw ArithmeticException("Negative square root")
                            sqrt(arg)
                        }
                        "cbrt" -> cbrt(arg)
                        "abs" -> abs(arg)
                        "exp" -> exp(arg)
                        "floor" -> floor(arg)
                        "ceil" -> ceil(arg)
                        "round" -> round(arg)
                        else -> throw IllegalArgumentException("Unknown function $token")
                    }
                    stack.push(res)
                }
                isOperator(token) -> {
                    if (stack.size < 2) throw IllegalArgumentException("Malformed expression")
                    val b = stack.pop()
                    val a = stack.pop()
                    val res = when (token) {
                        "+" -> a + b
                        "-" -> a - b
                        "*" -> a * b
                        "/" -> {
                            if (abs(b) < 1e-14) throw ArithmeticException("Cannot divide by zero")
                            a / b
                        }
                        "^" -> a.pow(b)
                        else -> throw IllegalArgumentException("Unknown operator $token")
                    }
                    stack.push(res)
                }
            }
        }

        if (stack.size != 1) throw IllegalArgumentException("Invalid expression structure")
        return stack.pop()
    }

    private fun factorial(n: Int): Double {
        if (n > 170) return Double.POSITIVE_INFINITY
        var result = 1.0
        for (i in 2..n) {
            result *= i
        }
        return result
    }

    fun formatResult(value: Double, precision: Int = 6): String {
        if (value.isNaN()) return "NaN"
        if (value.isInfinite()) return if (value > 0) "∞" else "-∞"

        // If integer value
        if (abs(value - round(value)) < 1e-9 && abs(value) < 1e12) {
            return round(value).toLong().toString()
        }

        return try {
            val bd = BigDecimal(value, MathContext.DECIMAL64)
                .setScale(precision, RoundingMode.HALF_UP)
                .stripTrailingZeros()
            bd.toPlainString()
        } catch (e: Exception) {
            String.format("%.${precision}f", value).trimEnd('0').trimEnd('.')
        }
    }
}
