package com.example.engine

import kotlin.math.*

object PhysicsScienceSolver {

    // Physical Constants
    const val G = 6.67430e-11 // m^3 kg^-1 s^-2
    const val g_earth = 9.81 // m/s^2
    const val c_light = 3.0e8 // m/s
    const val h_planck = 6.62607e-34 // J s
    const val k_coulomb = 8.98755e9 // N m^2 / C^2
    const val R_gas = 8.314 // J / (mol K)

    data class PhysicsResult(
        val title: String,
        val formulaUsed: String,
        val valuesMap: Map<String, String>,
        val steps: List<String>
    )

    // 1. KINEMATICS & MOTION
    fun solveKinematics(
        u: Double?, // initial velocity (m/s)
        v: Double?, // final velocity (m/s)
        a: Double?, // acceleration (m/s^2)
        t: Double?, // time (s)
        s: Double?  // displacement (m)
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val map = mutableMapOf<String, String>()

        var calcU = u
        var calcV = v
        var calcA = a
        var calcT = t
        var calcS = s

        steps.add("Std 9-11 Kinematics Equations:")
        steps.add("1) v = u + at")
        steps.add("2) s = ut + ½at²")
        steps.add("3) v² = u² + 2as")

        // Solve missing parameters iteratively
        for (i in 1..3) {
            if (calcV == null && calcU != null && calcA != null && calcT != null) {
                calcV = calcU + calcA * calcT
                steps.add("Applied v = u + at ⇒ v = $calcU + ($calcA)×($calcT) = ${formatSI(calcV, "m/s")}")
            }
            if (calcS == null && calcU != null && calcT != null && calcA != null) {
                calcS = calcU * calcT + 0.5 * calcA * calcT * calcT
                steps.add("Applied s = ut + ½at² ⇒ s = ($calcU)($calcT) + 0.5($calcA)($calcT)² = ${formatSI(calcS, "m")}")
            }
            if (calcA == null && calcV != null && calcU != null && calcT != null && calcT != 0.0) {
                calcA = (calcV - calcU) / calcT
                steps.add("Applied a = (v - u)/t ⇒ a = ($calcV - $calcU)/$calcT = ${formatSI(calcA, "m/s²")}")
            }
            if (calcT == null && calcV != null && calcU != null && calcA != null && calcA != 0.0) {
                calcT = (calcV - calcU) / calcA
                steps.add("Applied t = (v - u)/a ⇒ t = ($calcV - $calcU)/$calcA = ${formatSI(calcT, "s")}")
            }
            if (calcU == null && calcV != null && calcA != null && calcS != null) {
                val uSq = calcV * calcV - 2 * calcA * calcS
                if (uSq >= 0) {
                    calcU = sqrt(uSq)
                    steps.add("Applied u = √(v² - 2as) ⇒ u = √($calcV² - 2($calcA)($calcS)) = ${formatSI(calcU, "m/s")}")
                }
            }
            if (calcV == null && calcU != null && calcA != null && calcS != null) {
                val vSq = calcU * calcU + 2 * calcA * calcS
                if (vSq >= 0) {
                    calcV = sqrt(vSq)
                    steps.add("Applied v = √(u² + 2as) ⇒ v = √($calcU² + 2($calcA)($calcS)) = ${formatSI(calcV, "m/s")}")
                }
            }
        }

        calcU?.let { map["Initial Velocity (u)"] = formatSI(it, "m/s") }
        calcV?.let { map["Final Velocity (v)"] = formatSI(it, "m/s") }
        calcA?.let { map["Acceleration (a)"] = formatSI(it, "m/s²") }
        calcT?.let { map["Time (t)"] = formatSI(it, "s") }
        calcS?.let { map["Displacement (s)"] = formatSI(it, "m") }

        return PhysicsResult("1D Motion / Kinematics", "v = u + at, s = ut + ½at², v² = u² + 2as", map, steps)
    }

    // 2. PROJECTILE MOTION (Std 11)
    fun solveProjectile(u: Double, angleDeg: Double, g: Double = g_earth): PhysicsResult {
        val steps = mutableListOf<String>()
        val rad = Math.toRadians(angleDeg)

        val ux = u * cos(rad)
        val uy = u * sin(rad)

        val timeOfFlight = (2 * u * sin(rad)) / g
        val maxHeight = (u * u * sin(rad) * sin(rad)) / (2 * g)
        val range = (u * u * sin(2 * rad)) / g

        steps.add("Given: Initial Velocity u = $u m/s, Angle θ = $angleDeg°, Gravity g = $g m/s²")
        steps.add("1. Horizontal Component uₓ = u cos(θ) = $u × cos($angleDeg°) = ${formatSI(ux, "m/s")}")
        steps.add("2. Vertical Component uᵧ = u sin(θ) = $u × sin($angleDeg°) = ${formatSI(uy, "m/s")}")
        steps.add("3. Time of Flight T = (2 u sin θ) / g = (2 × $u × sin($angleDeg°)) / $g = ${formatSI(timeOfFlight, "s")}")
        steps.add("4. Maximum Height H = (u² sin² θ) / 2g = (${u}² × sin²($angleDeg°)) / (2 × $g) = ${formatSI(maxHeight, "m")}")
        steps.add("5. Horizontal Range R = (u² sin 2θ) / g = (${u}² × sin(${2 * angleDeg}°)) / $g = ${formatSI(range, "m")}")

        val map = mapOf(
            "Initial Velocity (u)" to formatSI(u, "m/s"),
            "Launch Angle (θ)" to "$angleDeg°",
            "uₓ (Horizontal)" to formatSI(ux, "m/s"),
            "uᵧ (Vertical)" to formatSI(uy, "m/s"),
            "Time of Flight (T)" to formatSI(timeOfFlight, "s"),
            "Maximum Height (H)" to formatSI(maxHeight, "m"),
            "Horizontal Range (R)" to formatSI(range, "m")
        )

        return PhysicsResult("Projectile Motion", "T = 2u sinθ/g, H = u² sin²θ/2g, R = u² sin(2θ)/g", map, steps)
    }

    // 3. WORK, ENERGY & POWER (Std 9 & 11)
    fun solveWorkEnergyPower(
        mass: Double?,
        velocity: Double?,
        height: Double?,
        force: Double?,
        distance: Double?,
        time: Double?
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val map = mutableMapOf<String, String>()

        var ke: Double? = null
        var pe: Double? = null
        var work: Double? = null
        var power: Double? = null

        if (mass != null && velocity != null) {
            ke = 0.5 * mass * velocity * velocity
            steps.add("Kinetic Energy KE = ½ m v² = 0.5 × $mass × ($velocity)² = ${formatSI(ke, "J")}")
            map["Kinetic Energy (KE)"] = formatSI(ke, "J")
        }

        if (mass != null && height != null) {
            pe = mass * g_earth * height
            steps.add("Potential Energy PE = m g h = $mass × $g_earth × $height = ${formatSI(pe, "J")}")
            map["Potential Energy (PE)"] = formatSI(pe, "J")
        }

        if (force != null && distance != null) {
            work = force * distance
            steps.add("Work Done W = F × d = $force × $distance = ${formatSI(work, "J")}")
            map["Work Done (W)"] = formatSI(work, "J")
        } else if (ke != null) {
            work = ke
        } else if (pe != null) {
            work = pe
        }

        if (work != null && time != null && time > 0.0) {
            power = work / time
            val hp = power / 746.0
            steps.add("Power P = W / t = $work / $time = ${formatSI(power, "W")} (${roundTwoDec(hp)} HP)")
            map["Power (P)"] = "${formatSI(power, "W")} (${roundTwoDec(hp)} Horsepower)"
        }

        return PhysicsResult("Work, Energy & Power", "KE = ½mv², PE = mgh, W = F·d, P = W/t", map, steps)
    }

    // 4. GRAVITATION & ORBITAL MOTION (Std 9 & 11)
    fun solveGravitation(
        m1: Double,
        m2: Double,
        distanceR: Double
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val force = (G * m1 * m2) / (distanceR * distanceR)

        steps.add("Newton's Law of Gravitation: F = (G × m₁ × m₂) / r²")
        steps.add("G = 6.6743 × 10⁻¹¹ N m²/kg²")
        steps.add("F = (6.6743×10⁻¹¹ × $m1 × $m2) / ($distanceR)² = ${formatSI(force, "N")}")

        // Earth comparison calculation if m1 = Earth Mass 5.972e24 kg & r = Earth Radius 6.371e6 m
        val gLocal = (G * m1) / (distanceR * distanceR)
        val vOrbital = sqrt((G * m1) / distanceR)
        val vEscape = sqrt(2 * gLocal * distanceR)

        steps.add("Surface / Acceleration due to Gravity g' = GM₁/r² = ${formatSI(gLocal, "m/s²")}")
        steps.add("Orbital Velocity vₒ = √(GM₁/r) = ${formatSI(vOrbital, "m/s")}")
        steps.add("Escape Velocity vₑ = √(2g'r) = ${formatSI(vEscape, "m/s")}")

        val map = mapOf(
            "Gravitational Force (F)" to formatSI(force, "N"),
            "Gravity Acceleration (g')" to formatSI(gLocal, "m/s²"),
            "Orbital Velocity (vₒ)" to formatSI(vOrbital, "m/s"),
            "Escape Velocity (vₑ)" to formatSI(vEscape, "m/s")
        )

        return PhysicsResult("Universal Gravitation", "F = G m₁m₂ / r², g = GM/R², vₑ = √(2gR)", map, steps)
    }

    // 5. ELECTRICITY & OHM'S LAW / CIRCUITS (Std 10 & 12)
    fun solveCircuits(
        voltage: Double?,
        current: Double?,
        resistance: Double?,
        resistorsList: List<Double>,
        isSeries: Boolean
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val map = mutableMapOf<String, String>()

        var calcR: Double? = resistance
        var calcV: Double? = voltage
        var calcI: Double? = current

        if (resistorsList.isNotEmpty()) {
            if (isSeries) {
                val req = resistorsList.sum()
                steps.add("Resistors in Series: Rₛ = R₁ + R₂ + ... = ${resistorsList.joinToString(" + ")} = ${formatSI(req, "Ω")}")
                calcR = req
            } else {
                val reqInv = resistorsList.sumOf { 1.0 / it }
                val req = 1.0 / reqInv
                steps.add("Resistors in Parallel: 1/Rₚ = ∑ (1/Rᵢ) ⇒ Rₚ = 1 / (${resistorsList.joinToString(" + ") { "1/$it" }}) = ${formatSI(req, "Ω")}")
                calcR = req
            }
        }

        if (calcV != null && calcI != null && calcR == null) {
            calcR = calcV / calcI
            steps.add("Ohm's Law: R = V / I = $calcV / $calcI = ${formatSI(calcR, "Ω")}")
        } else if (calcV != null && calcR != null && calcI == null) {
            calcI = calcV / calcR
            steps.add("Ohm's Law: I = V / R = $calcV / $calcR = ${formatSI(calcI, "A")}")
        } else if (calcI != null && calcR != null && calcV == null) {
            calcV = calcI * calcR
            steps.add("Ohm's Law: V = I × R = $calcI × $calcR = ${formatSI(calcV, "V")}")
        }

        calcV?.let { map["Voltage (V)"] = formatSI(it, "V") }
        calcI?.let { map["Current (I)"] = formatSI(it, "A") }
        calcR?.let { map["Equivalent Resistance (R)"] = formatSI(it, "Ω") }

        if (calcV != null && calcI != null) {
            val power = calcV * calcI
            val energy1hr = power * 3600.0 / 3.6e6 // kWh
            steps.add("Electrical Power P = V × I = $calcV × $calcI = ${formatSI(power, "W")}")
            steps.add("Energy consumed in 1 hour = ${roundTwoDec(energy1hr)} kWh (Commercial Units)")
            map["Electrical Power (P)"] = formatSI(power, "W")
            map["1 Hr Consumption"] = "${roundTwoDec(energy1hr)} kWh"
        }

        return PhysicsResult("Electricity & Ohm's Law", "V = IR, P = VI = I²R = V²/R, Rₛ = ∑R, 1/Rₚ = ∑(1/R)", map, steps)
    }

    // 6. COULOMB'S LAW & CAPACITANCE (Std 12)
    fun solveElectrostatics(
        q1: Double,
        q2: Double,
        distanceR: Double,
        capacitance: Double?,
        capVoltage: Double?
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val map = mutableMapOf<String, String>()

        val force = (k_coulomb * abs(q1 * q2)) / (distanceR * distanceR)
        steps.add("Coulomb's Law: F = k |q₁ q₂| / r² where k = 8.98755 × 10⁹ N m²/C²")
        steps.add("F = (8.98755×10⁹ × |$q1 × $q2|) / ($distanceR)² = ${formatSI(force, "N")}")
        map["Electrostatic Force (F)"] = formatSI(force, "N")

        if (capacitance != null && capVoltage != null) {
            val chargeQ = capacitance * capVoltage
            val energyU = 0.5 * capacitance * capVoltage * capVoltage
            steps.add("Capacitor Charge Q = C × V = $capacitance × $capVoltage = ${formatSI(chargeQ, "C")}")
            steps.add("Energy Stored U = ½ C V² = 0.5 × $capacitance × ($capVoltage)² = ${formatSI(energyU, "J")}")
            map["Charge Stored (Q)"] = formatSI(chargeQ, "C")
            map["Energy Stored (U)"] = formatSI(energyU, "J")
        }

        return PhysicsResult("Electrostatics & Capacitors", "F = k q₁q₂/r², Q = CV, U = ½ CV²", map, steps)
    }

    // 7. OPTICS & LENSES / MIRRORS (Std 10 & 12)
    fun solveOptics(
        u: Double, // Object distance (sign convention: usually negative)
        f: Double, // Focal length
        isMirror: Boolean // true for Mirror, false for Lens
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val map = mutableMapOf<String, String>()

        if (isMirror) {
            // 1/f = 1/v + 1/u => 1/v = 1/f - 1/u => v = 1 / (1/f - 1/u)
            val invV = (1.0 / f) - (1.0 / u)
            if (abs(invV) < 1e-12) {
                steps.add("1/v = 1/f - 1/u = 0 ⇒ Image is at Infinity (v = ∞)")
                map["Image Distance (v)"] = "Infinity (∞)"
            } else {
                val v = 1.0 / invV
                val m = -v / u
                steps.add("Mirror Formula: 1/f = 1/v + 1/u")
                steps.add("1/v = 1/f - 1/u = (1/$f) - (1/$u) = $invV m⁻¹")
                steps.add("Image Distance v = ${formatSI(v, "cm")}")
                steps.add("Magnification m = -v / u = -($v) / ($u) = ${roundTwoDec(m)}")

                val nature = if (v < 0) "Real & Inverted" else "Virtual & Erect"
                steps.add("Image Nature: $nature")

                map["Image Distance (v)"] = formatSI(v, "cm")
                map["Magnification (m)"] = "${roundTwoDec(m)} ($nature)"
            }
        } else {
            // Lens Formula: 1/f = 1/v - 1/u => 1/v = 1/f + 1/u => v = 1 / (1/f + 1/u)
            val invV = (1.0 / f) + (1.0 / u)
            if (abs(invV) < 1e-12) {
                steps.add("1/v = 1/f + 1/u = 0 ⇒ Image is at Infinity (v = ∞)")
                map["Image Distance (v)"] = "Infinity (∞)"
            } else {
                val v = 1.0 / invV
                val m = v / u
                val powerD = 100.0 / f // power in Diopters if f in cm
                steps.add("Lens Formula: 1/f = 1/v - 1/u")
                steps.add("1/v = 1/f + 1/u = (1/$f) + (1/$u) = $invV cm⁻¹")
                steps.add("Image Distance v = ${formatSI(v, "cm")}")
                steps.add("Magnification m = v / u = $v / $u = ${roundTwoDec(m)}")
                steps.add("Lens Power P = 1 / f (in m) = 100 / $f = ${roundTwoDec(powerD)} D (Diopters)")

                val nature = if (v > 0) "Real & Inverted" else "Virtual & Erect"
                steps.add("Image Nature: $nature")

                map["Image Distance (v)"] = formatSI(v, "cm")
                map["Magnification (m)"] = "${roundTwoDec(m)} ($nature)"
                map["Power of Lens (P)"] = "${roundTwoDec(powerD)} D"
            }
        }

        return PhysicsResult(
            if (isMirror) "Mirror Optics" else "Lens Optics",
            if (isMirror) "1/f = 1/v + 1/u, m = -v/u" else "1/f = 1/v - 1/u, m = v/u, P = 1/f",
            map, steps
        )
    }

    // 8. WAVES & SNELL'S LAW (Std 10 & 12)
    fun solveWavesAndSnell(
        freq: Double?,
        wavelength: Double?,
        angle1Deg: Double?,
        n1: Double?,
        n2: Double?
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val map = mutableMapOf<String, String>()

        if (freq != null && wavelength != null) {
            val waveSpeed = freq * wavelength
            val period = 1.0 / freq
            steps.add("Wave Speed v = f × λ = $freq × $wavelength = ${formatSI(waveSpeed, "m/s")}")
            steps.add("Time Period T = 1 / f = 1 / $freq = ${formatSI(period, "s")}")
            map["Wave Speed (v)"] = formatSI(waveSpeed, "m/s")
            map["Time Period (T)"] = formatSI(period, "s")
        }

        if (angle1Deg != null && n1 != null && n2 != null && n2 != 0.0) {
            val sin1 = sin(Math.toRadians(angle1Deg))
            val sin2 = (n1 * sin1) / n2
            if (abs(sin2) <= 1.0) {
                val angle2Rad = asin(sin2)
                val angle2Deg = Math.toDegrees(angle2Rad)
                val criticalAngle = if (n1 > n2) Math.toDegrees(asin(n2 / n1)) else null

                steps.add("Snell's Law: n₁ sin(θ₁) = n₂ sin(θ₂)")
                steps.add("sin(θ₂) = (n₁ sin θ₁) / n₂ = ($n1 × sin($angle1Deg°)) / $n2 = ${roundTwoDec(sin2)}")
                steps.add("Refracted Angle θ₂ = ${roundTwoDec(angle2Deg)}°")
                if (criticalAngle != null) {
                    steps.add("Critical Angle θ_c (for Total Internal Reflection) = asin(n₂/n₁) = ${roundTwoDec(criticalAngle)}°")
                    map["Critical Angle (θ_c)"] = "${roundTwoDec(criticalAngle)}°"
                }

                map["Refracted Angle (θ₂)"] = "${roundTwoDec(angle2Deg)}°"
            } else {
                steps.add("Total Internal Reflection occurs! sin(θ₂) = $sin2 > 1. No refraction into medium 2.")
                map["Refraction Result"] = "Total Internal Reflection (TIR)"
            }
        }

        return PhysicsResult("Waves & Refraction (Snell's Law)", "v = fλ, T = 1/f, n₁ sinθ₁ = n₂ sinθ₂", map, steps)
    }

    // 9. MODERN PHYSICS & PHOTONS (Std 12)
    fun solveModernPhysics(
        frequency: Double?,
        wavelength: Double?,
        massKg: Double?
    ): PhysicsResult {
        val steps = mutableListOf<String>()
        val map = mutableMapOf<String, String>()

        var calcFreq = frequency
        var calcLambda = wavelength

        if (calcFreq == null && calcLambda != null && calcLambda > 0.0) {
            calcFreq = c_light / calcLambda
            steps.add("f = c / λ = (3×10⁸) / $calcLambda = ${formatSI(calcFreq, "Hz")}")
        } else if (calcLambda == null && calcFreq != null && calcFreq > 0.0) {
            calcLambda = c_light / calcFreq
            steps.add("λ = c / f = (3×10⁸) / $calcFreq = ${formatSI(calcLambda, "m")}")
        }

        if (calcFreq != null) {
            val energyJoules = h_planck * calcFreq
            val energyeV = energyJoules / 1.60218e-19
            steps.add("Photon Energy E = h × f = (6.626×10⁻³⁴) × $calcFreq = ${formatSI(energyJoules, "J")} (${roundTwoDec(energyeV)} eV)")
            map["Photon Energy (E)"] = "${formatSI(energyJoules, "J")} (${roundTwoDec(energyeV)} eV)"
        }

        if (massKg != null) {
            val eMass = massKg * c_light * c_light
            steps.add("Einstein Mass-Energy Equivalence: E = m c² = $massKg × (3×10⁸)² = ${formatSI(eMass, "J")}")
            map["Mass Energy (E = mc²)"] = formatSI(eMass, "J")

            val deBroglieLambda = h_planck / (massKg * 100.0) // assumed v=100 m/s
            steps.add("De Broglie Wavelength (at v = 100 m/s): λ = h / p = ${formatSI(deBroglieLambda, "m")}")
            map["De Broglie Wavelength"] = formatSI(deBroglieLambda, "m")
        }

        return PhysicsResult("Modern Physics & Photons", "E = hf = hc/λ, E = mc², λ = h/p", map, steps)
    }

    // Helper formatting utilities
    private fun roundTwoDec(value: Double): Double {
        if (value.isNaN() || value.isInfinite()) return value
        return (value * 100.0).roundToLong() / 100.0
    }

    fun formatSI(value: Double, unit: String): String {
        if (value.isNaN()) return "NaN $unit"
        if (value.isInfinite()) return "∞ $unit"
        val absVal = abs(value)
        return when {
            absVal == 0.0 -> "0 $unit"
            absVal >= 1e9 -> "${roundTwoDec(value / 1e9)} G$unit"
            absVal >= 1e6 -> "${roundTwoDec(value / 1e6)} M$unit"
            absVal >= 1e3 -> "${roundTwoDec(value / 1e3)} k$unit"
            absVal < 1e-6 -> String.format("%.3e %s", value, unit)
            absVal < 1e-3 -> "${roundTwoDec(value * 1e3)} m$unit"
            else -> "${roundTwoDec(value)} $unit"
        }
    }
}
