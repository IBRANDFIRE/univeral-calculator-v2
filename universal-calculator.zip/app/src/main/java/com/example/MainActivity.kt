package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.AppDatabase
import com.example.data.CalcRepository
import com.example.data.SettingsManager
import com.example.ui.components.rememberHapticFeedback
import com.example.ui.components.rememberSoundFeedback
import com.example.ui.models.CalcCategory
import com.example.ui.models.CalculatorItem
import com.example.ui.models.CalculatorRegistry
import com.example.ui.screens.*
import com.example.ui.theme.UniversalCalculatorTheme

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Standard : Screen("standard", "Standard", Icons.Default.Calculate)
    object Scientific : Screen("scientific", "Scientific", Icons.Default.ShowChart)
    object Financial : Screen("financial", "Financial", Icons.Default.MonetizationOn)
    object Converters : Screen("converters", "Converters", Icons.Default.SwapHoriz)
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Default.Dashboard)
    object HealthUtilities : Screen("health_utilities", "Health & DIY", Icons.Default.FitnessCenter)
    object History : Screen("history", "History Tape", Icons.Default.History)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = AppDatabase.getInstance(applicationContext)
        val repository = CalcRepository(database.calcHistoryDao())
        val settingsManager = SettingsManager(applicationContext)

        setContent {
            val settings by settingsManager.settings.collectAsState()
            val soundManager = rememberSoundFeedback(settings.soundEnabled)
            val haptics = rememberHapticFeedback(settings.hapticsEnabled, soundManager)

            UniversalCalculatorTheme(
                themeMode = settings.themeMode,
                accent = settings.accentPalette
            ) {
                MainAppScaffold(
                    repository = repository,
                    settingsManager = settingsManager,
                    haptics = haptics
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(
    repository: CalcRepository,
    settingsManager: SettingsManager,
    haptics: com.example.ui.components.HapticFeedbackManager
) {
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Standard) }
    var previousScreen by remember { mutableStateOf<Screen?>(null) }
    var initialSubTab by remember { mutableStateOf(0) }

    fun navigateTo(screen: Screen, subTab: Int = 0) {
        haptics.tick()
        if (currentScreen != screen) {
            previousScreen = currentScreen
            currentScreen = screen
        }
        initialSubTab = subTab
    }

    val bottomNavItems = listOf(
        Screen.Standard,
        Screen.Scientific,
        Screen.Financial,
        Screen.Converters,
        Screen.Dashboard
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (currentScreen is Screen.HealthUtilities || currentScreen is Screen.History || currentScreen is Screen.Settings) {
                TopAppBar(
                    title = { Text(currentScreen.title) },
                    navigationIcon = {
                        IconButton(
                            onClick = {
                                haptics.tick()
                                currentScreen = previousScreen ?: Screen.Dashboard
                            },
                            modifier = Modifier.testTag("top_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    modifier = Modifier.testTag("app_top_bar")
                )
            }
        },
        bottomBar = {
            NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
                bottomNavItems.forEach { item ->
                    val isSelected = currentScreen.route == item.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { navigateTo(item, 0) },
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title) },
                        modifier = Modifier.testTag("nav_item_${item.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    Screen.Standard -> {
                        StandardCalculatorScreen(
                            repository = repository,
                            settingsManager = settingsManager,
                            haptics = haptics,
                            onNavigateToHistory = { navigateTo(Screen.History) }
                        )
                    }
                    Screen.Scientific -> {
                        ScientificGraphingScreen(
                            repository = repository,
                            haptics = haptics,
                            initialTab = initialSubTab
                        )
                    }
                    Screen.Financial -> {
                        FinancialScreen(
                            repository = repository,
                            haptics = haptics,
                            initialTab = initialSubTab
                        )
                    }
                    Screen.Converters -> {
                        ConvertersScreen(
                            repository = repository,
                            haptics = haptics,
                            initialTab = initialSubTab
                        )
                    }
                    Screen.Dashboard -> {
                        DashboardScreen(
                            repository = repository,
                            settingsManager = settingsManager,
                            haptics = haptics,
                            onOpenCalculator = { calcItem ->
                                routeToCalculator(calcItem) { targetScreen, tabIdx ->
                                    navigateTo(targetScreen, tabIdx)
                                }
                            },
                            onOpenCategory = { category ->
                                when (category) {
                                    CalcCategory.STANDARD -> navigateTo(Screen.Standard, 0)
                                    CalcCategory.SCIENTIFIC -> navigateTo(Screen.Scientific, 0)
                                    CalcCategory.FINANCIAL -> navigateTo(Screen.Financial, 0)
                                    CalcCategory.CONVERTERS -> navigateTo(Screen.Converters, 0)
                                    CalcCategory.HEALTH -> navigateTo(Screen.HealthUtilities, 0)
                                    CalcCategory.UTILITIES -> navigateTo(Screen.HealthUtilities, 3)
                                }
                            },
                            onOpenSettings = { navigateTo(Screen.Settings) },
                            onOpenHistory = { navigateTo(Screen.History) }
                        )
                    }
                    Screen.HealthUtilities -> {
                        HealthUtilitiesScreen(
                            repository = repository,
                            haptics = haptics,
                            initialTab = initialSubTab
                        )
                    }
                    Screen.History -> {
                        HistoryTapeScreen(
                            repository = repository,
                            haptics = haptics
                        )
                    }
                    Screen.Settings -> {
                        SettingsScreen(
                            settingsManager = settingsManager,
                            haptics = haptics
                        )
                    }
                }
            }
        }
    }
}

private fun routeToCalculator(item: CalculatorItem, onRoute: (Screen, Int) -> Unit) {
    when (item.id) {
        "standard" -> onRoute(Screen.Standard, 0)
        "percentage" -> onRoute(Screen.Standard, 1)
        "tally" -> onRoute(Screen.Standard, 2)
        "student_math" -> onRoute(Screen.Scientific, 0)
        "physics_science" -> onRoute(Screen.Scientific, 1)
        "series_sum" -> onRoute(Screen.Scientific, 2)
        "scientific" -> onRoute(Screen.Standard, 0)
        "graphing" -> onRoute(Screen.Scientific, 3)
        "calculus" -> onRoute(Screen.Scientific, 4)
        "equations" -> onRoute(Screen.Scientific, 5)
        "matrix" -> onRoute(Screen.Scientific, 6)
        "statistics" -> onRoute(Screen.Scientific, 7)
        "emi" -> onRoute(Screen.Financial, 0)
        "sip" -> onRoute(Screen.Financial, 1)
        "currency" -> onRoute(Screen.Financial, 2)
        "tip" -> onRoute(Screen.Financial, 3)
        "tax" -> onRoute(Screen.Financial, 4)
        "margin" -> onRoute(Screen.Financial, 5)
        "retirement" -> onRoute(Screen.Financial, 6)
        "units" -> onRoute(Screen.Converters, 0)
        "base" -> onRoute(Screen.Converters, 1)
        "bmi" -> onRoute(Screen.HealthUtilities, 0)
        "tdee" -> onRoute(Screen.HealthUtilities, 1)
        "bodyfat" -> onRoute(Screen.HealthUtilities, 2)
        "macros" -> onRoute(Screen.HealthUtilities, 1)
        "pregnancy" -> onRoute(Screen.HealthUtilities, 0)
        "date" -> onRoute(Screen.HealthUtilities, 3)
        "age" -> onRoute(Screen.HealthUtilities, 3)
        "construction" -> onRoute(Screen.HealthUtilities, 4)
        "gpa" -> onRoute(Screen.HealthUtilities, 5)
        "aspect_ratio" -> onRoute(Screen.HealthUtilities, 5)
        else -> onRoute(Screen.Standard, 0)
    }
}
